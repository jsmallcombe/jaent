
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//



#include <TApplication.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TProfile2D.h>

#include <iostream>
#include <iomanip> 
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "exp_core.h"
#include "detector_class.h"
#include "auto_setup.h"
using namespace std;
int main(int argc, char *argv[]){	
// int argcb;
// char **argvb;	
TApplication *app = new TApplication("app", &argc, argv);
TH1::AddDirectory(kFALSE);//avoid name overwrites but could cause other memory histogram issues

//        h->SetDirectory(0);          for the current histogram h
	TCanvas * can_view = new TCanvas("can_view", "can_view", 800, 600);
	exp_core experiment(250);

	
	//PLATINUM TARGET	
	
	//2920.0
// 	experiment.set_targ(target(78,196,1500,180.0,0,giveme_areal(9.78,2),82,207));		
// 	experiment.set_beam(6,12,68.0);
// 	experiment.set_ejec(0,4);
// 	experiment.set_E_star(5.0);
// 	
// 	double com=experiment.get_beta_CoM();
// 	cout<<endl<<endl<<"Estimated recoil KE "<<(((1/sqrt(1-com*com))-1)*jam_phys_amu*204)<<endl;
// 	cout<<endl<<get_rel_mom(68.0,12);
// 	cout<<endl<<get_rel_mom((((1/sqrt(1-com*com))-1)*jam_phys_amu*204),204);
// 	
// 	experiment.set_lifetime_ns(100,21.4,9.78);	
// 	experiment.print_reaction();
// 	experiment.set_target_interaction(1);
// 	experiment.set_gamma(100);
// 	
// 	can_view->Divide(3,1);
// 	can_view->cd(1);
// 	experiment.draw_target_interaction();
// 	can_view->cd(2);
// 	experiment.fusion_evaporation_simplify=true;
// 	experiment.draw_target_interaction();
// 	can_view->cd(3);
// 	experiment.dist_target_beta.Draw();

	
	//PLATINUM TARGET RUTHERFORD CALCS	
	
	
	experiment.set_targ(target(78,196,1500,180.0,0,giveme_areal(9.78,2),82,207));		
	experiment.set_beam(6,12,68.0);
	experiment.set_target_interaction(2);
	experiment.set_target_primary_offset(0,0,-7.5);
	
	add_annulus(experiment,34.4,11,35);
// 	add_annulus(experiment,34.4,11,12);
	experiment.set_valid_part(0,true,true,false,false);
	
	add_annulus(experiment,0,9,1000);
	experiment.set_valid_part(1,false,false,false,false);


	experiment.auto_rutherford(100000,true);
	
	

	experiment.set_target_primary_offset(0,0,0);
	experiment.set_targ(target(82,207,giveme_areal(9.78,2),-180.0,0,1500,78,196));		
	experiment.set_beam(6,12,68.0);
	experiment.set_target_interaction(2);
	
	
	experiment.auto_rutherford(100000,true);

	//SAMARIUM TARGET	

	
	experiment.set_targ(target(62,152,4000));	
	experiment.set_beam(6,12,68.0);
	experiment.set_elastic();
	experiment.set_E_star(0.121);
	
// 	experiment.set_lifetime_ns(0.057,7.54);
	experiment.set_halflife_ns(1.504,7.54);
	experiment.set_gamma(100);
	experiment.set_rutherford(pi*0.05,pi);
	experiment.set_target_interaction(2);
	experiment.print_reaction();

	
	
	experiment.set_target_primary_offset(0,0,-7.5);
// 	add_annulus(experiment,34.4,11,35);
// 	experiment.set_valid_part(0,true,true,false,false);
// 	
// 	add_annulus(experiment,0,9,1000);
// 	experiment.set_valid_part(1,false,false,false,false);
	
	can_view->Divide(3,2);
	can_view->cd(1);
	experiment.draw_target_interaction();
	can_view->cd(2);
	experiment.set_valid_part(0,true,false,false,false);	
	experiment.draw_target_interaction(1,true);
	can_view->cd(3);
	experiment.set_valid_part(0,false,true,false,false);	
	experiment.draw_target_interaction(1,true);
	can_view->cd(4);
	experiment.draw_decay_Z();
	can_view->cd(5);
	experiment.set_valid_part(0,true,false,false,false);	
	experiment.draw_decay_Z(1,true);
	can_view->cd(6);
	experiment.set_valid_part(0,false,true,false,false);	
	experiment.draw_decay_Z(1,true);
// 	
// 	
// 	
	
	experiment.auto_rutherford(100000,true);
	
	

// 	experiment.draw_hits_3D(1,1,true,0.5,1,true,20);
// 	experiment.set_valid_part(0,false,true,false,false);
// 	experiment.draw_hits_3D(1,1,true,0.5,1,true,20);
//void draw_hits_3D(projection,particle_hit_multiplicity,obstructions,display_time,refresh_rate,counterpart_misses,run_time)

	
// 	
// 	
// 	can_view->cd(1);
// 	experiment.draw_exp();//Draw detectors 3D and arrow
// 	can_view->cd(2);
// 	experiment.draw_phi(true);//Draw detectors 3D and arrow
	
	
	
// 	experiment.draw_target_interaction();
// 	experiment.draw_xz_labels();
	
// 	TH1D* AA=experiment.fission_fragment_angles(1000)->ProjectionX("AA");
// 	
// 	TH1D* XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("XX");
// 	experiment.set_lifetime_ns(0.00001);	
// 	TH1D* YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("YY");
// 	experiment.set_lifetime_ns(0.000005);
// 	TH1D* ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("ZZ");
// 
// 	AA->SetLineColor(1);
// 	XX->SetLineColor(2);	
// 	YY->SetLineColor(3);
// 	ZZ->SetLineColor(4);
// 	
// 	XX->GetXaxis()->SetRangeUser(2.7,3.3);
// 	XX->SetTitle("4 Detectors Fusion");
// 	
// 	XX->DrawCopy();
// 	AA->DrawCopy("same");
// 	YY->DrawCopy("same");
// 	ZZ->DrawCopy("same");
// 
// 	can_view->cd(2);
// 	
// 	
// 	experiment.set_targ(W_186_twisted);
// 	experiment.set_beam(3,7,40.0);
// 	experiment.set_fusion();
// 	experiment.set_fission();	
// 	experiment.set_target_interaction(2);
// 	mwpc_auto_setup(experiment,1,false);
// 	add_target_ladder(experiment,15,80,5);
// 	
// 	experiment.print_reaction();
// 	experiment.print_detectables();
// 	experiment.print_doubles();
// 
// 	experiment.set_lifetime_ns();
// 	AA=experiment.fission_fragment_angles(1000)->ProjectionX("A");
// 	XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("X");
// 	experiment.set_lifetime_ns(0.00001);	
// 	YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("Y");
// 	experiment.set_lifetime_ns(0.000005);
// 	ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("Z");
// 
// 	AA->SetLineColor(1);	
// 	XX->SetLineColor(2);	
// 	YY->SetLineColor(3);
// 	ZZ->SetLineColor(4);
// 	
// 	XX->GetXaxis()->SetRangeUser(2.7,3.3);
// 	XX->SetTitle("2 Detectors Fusion");
// 	
// 	XX->DrawCopy();
// 	AA->DrawCopy("same");
// 	YY->DrawCopy("same");
// 	ZZ->DrawCopy("same");
// 
// 	
// 	
// 	
// 	experiment.set_lifetime_ns();
// 	
// 	can_view->cd(3);
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(3,7,40.0);
// 	experiment.set_elastic();
// 	experiment.set_E_star(28);
// 	experiment.set_uniform(0.99*pi,pi);
// 	experiment.set_fission();	
// 	experiment.set_target_interaction(2);
// 	mwpc_auto_setup(experiment,0,false);
// 	add_target_ladder(experiment,15,80,5);
// 
// 	
// 	experiment.print_reaction();
// 	experiment.print_detectables();
// 	experiment.print_doubles();
// 
// 	
// 	AA=experiment.fission_fragment_angles(1000)->ProjectionX("AAAA");
// 	
// 	XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("XXXX");
// 	experiment.set_lifetime_ns(0.0001);	
// 	YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("YYYY");
// 	experiment.set_lifetime_ns(0.001);
// 	ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("ZZZZ");
// 	AA->SetLineColor(1);
// 	XX->SetLineColor(2);	
// 	YY->SetLineColor(3);
// 	ZZ->SetLineColor(4);
// 	
// 	XX->GetXaxis()->SetRangeUser(2.7,3.3);
// 	XX->SetTitle("4 Detectors Scatter");
// 	
// 	XX->DrawCopy();
// 	AA->DrawCopy("same");
// 	YY->DrawCopy("same");
// 	ZZ->DrawCopy("same");
// 
// 	
// 	
// 	experiment.set_lifetime_ns();	
// 	can_view->cd(4);
// 	
// 	experiment.set_targ(W_186_twisted);
// 	experiment.set_beam(3,7,40.0);
// 	experiment.set_elastic();
// 	experiment.set_E_star(28);
// 	experiment.set_uniform(0.99*pi,pi);
// 	experiment.set_fission();	
// 	experiment.set_target_interaction(1);
// 	mwpc_auto_setup(experiment,1,false);
// 	add_target_ladder(experiment,15,80,5);
// 
// 	
// 	experiment.print_reaction();
// 	experiment.print_detectables();
// 	experiment.print_doubles();
// 
// 
// 	
// 	AA=experiment.fission_fragment_angles(1000)->ProjectionX("AAA");
// 	
// 	XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("XXX");
// 	experiment.set_lifetime_ns(0.0001);	
// 	YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("YYY");
// 	experiment.set_lifetime_ns(0.001);
// 	ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("ZZZ");
// 	AA->SetLineColor(1);
// 	XX->SetLineColor(2);	
// 	YY->SetLineColor(3);
// 	ZZ->SetLineColor(4);
// 	
// 	XX->GetXaxis()->SetRangeUser(2.7,3.3);
// 	XX->SetTitle("2 Detectors Scatter");
// 	
// 	XX->DrawCopy();
// 	AA->DrawCopy("same");
// 	YY->DrawCopy("same");
// 	ZZ->DrawCopy("same");
	
	
	
	
	
	
	
	
	
	
	
cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;	
	app->Run();
	return 0;
}	
	
	