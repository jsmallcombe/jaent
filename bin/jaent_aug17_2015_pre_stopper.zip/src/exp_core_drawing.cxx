
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#include "exp_core.h"

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Public Members Functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

void exp_core::draw_fill(int select)
{	
	switch ( select ){
		case 1:
			twodee->Reset();
			twodee->GetXaxis()->SetTitle("Y-axis [mm]");
			twodee->GetYaxis()->SetTitle("Z-axis [mm]");
			break;
		case 2:
			twodee->Reset();
			twodee->GetXaxis()->SetTitle("X-axis [mm]");
			twodee->GetYaxis()->SetTitle("Z-axis [mm]");
			break;
		case 3:
			twodee->Reset();
			twodee->GetXaxis()->SetTitle("X-axis [mm]");
			twodee->GetYaxis()->SetTitle("Y-axis [mm]");
			break;
		default:threedee->Reset();
	}		


	for(int i=0;(unsigned)i<detectors.size();i++){
		if(select>0) detectors[i].add_draw(twodee,select);
		else detectors[i].add_draw(threedee);	
	}
}

void exp_core::draw_exp(int select){if(gPad){
	gPad->cd();

	this->draw_fill(select);
	if(select>0) twodee->Draw();
	else{ threedee->Add(beamarrow);
		threedee->Draw();
	}	
//	delete drawhist;
// 	drawhist = (TH3D*)threedee->Clone();
// 	threedee->Copy(*drawhist);
// 	drawhist->Add(beamarrow);
// 	drawhist->Draw();

	gPad->Update();
}}
void exp_core::draw_phi(bool fill){if(gPad){
	gPad->cd();
	tp_proj->Draw();
	for(int i=0;(unsigned)i<detectors.size();i++){
		if(fill){detectors[i].tp()->SetFillColor(i+1);
			detectors[i].tp()->Draw("sameF");}
		else detectors[i].tp()->Draw("same");
	}
	gPad->Update();
}}
void exp_core::draw_xz_labels(){if(gPad){
	gPad->cd();
	this->draw_exp(2);
	for(int i=0;(unsigned)i<detectors.size();i++){
		TText* label= new TText();
		label->SetTextAlign(22);
		label->SetTextSize(0.06);	
		stringstream SS;
		SS<<i;
		label->DrawText(-detectors[i].Xn(), -detectors[i].Zn(), SS.str().c_str());

	}
	gPad->Update();
}}

void exp_core::draw_boost_detectors(bool recoil){if(gPad){
	gPad->cd();	
	beamarrow->Copy(*drawhist);	
	double p0=P_1_CoM;
	double m0=reco_mass;
	if(!recoil) m0=ejec_mass;
	
	//loop over all detectors (obs)
	for(int i=0;(unsigned)i<detectors.size();i++){
		double t,p;
		TVector3 point;
		detector* d=&detectors[i];
		double magg=sqrt(d->X()*d->X()+d->Y()*d->Y()+d->Z()*d->Z());
		for(int j=0;j<detectors[i].tp()->GetN();j++){
			detectors[i].tp()->GetPoint(j,t,p);
			double* ret=lab_boost_CMP_query(beta_CoM,t,p0,m0);

			//two solutions if in inverse kinematics
			point.SetMagThetaPhi(magg, ret[0], p);
			drawhist->Fill(point.X(),point.Z(),point.Y());
			point.SetMagThetaPhi(magg, ret[2], p);
			drawhist->Fill(point.X(),point.Z(),point.Y());			
			delete ret;
		}		
	}
	drawhist->Draw();
	gPad->Update();
}}


void exp_core::draw_target_interaction(int mult,bool obstructions){if(gPad){
	gPad->cd();	
	
	TH1D interaction("interaction","interaction",302,-1.01,2.02);
	TH1D recoil_decay("recoil_decay","recoil_decay",302,-1.01,2.02);
	recoil_decay.SetLineColor(2);
	interaction.GetXaxis()->SetTitle("Target Fraction");
	
	for(int i=0;i<1000000;i++){	
		this->gen_event();
		if(mult>0&&mult<5){
			this->det_check_hits_all(obstructions);
			if(this->current_multiplicity()>=mult){
				interaction.Fill(current_target_fraction);
				recoil_decay.Fill(decay_target_fraction);
				i+=100;
			}
			i--;				
		}else{
			interaction.Fill(current_target_fraction);
			recoil_decay.Fill(decay_target_fraction);
		}	
	}

	gPad->SetLogy();interaction.SetMinimum(10);
	interaction.DrawCopy();
	recoil_decay.DrawCopy("same");
	gPad->Update();
}}

void exp_core::draw_decay_Z(int mult,bool obstructions){if(gPad&&decay_events){
	gPad->cd();	
	
	TH1D decay_Z("decay_Z","decay_Z",4000,-worldsize,worldsize);
	decay_Z.SetLineColor(2);
	decay_Z.GetXaxis()->SetTitle("World Z [mm]");
	
	for(int i=0;i<1000000;i++){	
		this->gen_event();
		if(mult>0&&mult<5){
			this->det_check_hits_all(obstructions);
			if(this->current_multiplicity()>=mult){
				decay_Z.Fill(offset_decay.Z());
				i+=100;
			}
			i--;
		}else{
			decay_Z.Fill(offset_decay.Z());
		}	
	}

	gPad->SetLogy();decay_Z.SetMinimum(10);
	decay_Z.DrawCopy();
	gPad->Update();
}}




void exp_core::draw_hits_3D(int projection,int multin,bool obstructions,double display_time,int refresh_rate,bool counterpart_misses,double run_time){if(gPad){//only starts if there is an active pad
	TStopwatch tstop;
	bool mega=false;
	if(projection==4)mega=true;//if doing the big 4 way draw
		
	int det_hits_only=0;
	if(counterpart_misses)det_hits_only=-1;//set the -1 flag that draws misses if requested
	   
	TPad* pad =(TPad*) gPad;//pointer to the pad
	gStyle->SetOptStat(0);
	if(mega)pad->Divide(2,2);//divide if doing big 4way
	
	//adjust the individual particle hists binning for speed
	for(int i=0;i<4;i++)
		if(projection==0||mega)part_vl[i]->SetBins(100,-worldsize,worldsize,100,-worldsize,worldsize,100,-worldsize,worldsize);
		else part_vl[i]->SetBins(200,-worldsize,worldsize,200,-worldsize,worldsize,200,-worldsize,worldsize);
	
	int lim=2;//save on some unneeded drawing
	if(decay_events)lim=4;
	
	if(projection==0||mega){//if 3D or all
		if(mega)pad->cd(1);
		this->draw_fill(0);//fill detector outlines into "threedee"
		threedee->Copy(*drawhist); //make a copy
		drawhist->Rebin3D(3,3,3);  //rebin the copy (for speed)
		drawhist->Draw(); //draw the copy
		for(int i=0;i<lim;i++){
			part_vl[i]->Draw("same");//Draw the paricles overlay
			if(targ_fusion&&i==0){i++;}//save on some unneeded drawing
		}
	}
	
	for(int j=1;j<4;j++){//do the same for the 2D projections
		if(projection==j||mega){
			if(mega)pad->cd(j+1);
			this->draw_fill(j);//fill twodee
			twodee->DrawCopy();//drawcopy because overwritten
			for(int i=0;i<lim;i++){
				part_vl[i]->Project3D(projection_names[j].c_str())->Draw("same");//Draw the paricles overlay
				if(targ_fusion&&i==0){i++;}//save on some unneeded drawing
			}
		}
	}
	
	int refresh_count=0;
	double timebzero=tstop.RealTime();tstop.Continue();			
	double T=timebzero;
	
	int counter=0;//Main loop, will exit if no valid draw events for 10000000 events generated
	while(counter<10000000){counter++;
		
		this->gen_event();//gen event and check hits (with or without obstructions)
		this->det_check_hits_all(obstructions);
		
		int mult=this->current_multiplicity();
		
		//stop drawing many blanks if everything stopped in target
		if(multin==0&&mult==0){mult--;for(int i=0;i<lim;i++)if(lor_point[i]->P()>0)mult++;}
		
		//Draw loop
		if(mult>multin-1){//if current event at least required multiplicity (including 0) do a draw
			refresh_count++;//count 1 draw;
			counter=0;//good to contiune
			
			for(int i=0;i<lim;i++){//particle loop
				
				// Dont bother draw if P=0
				if(lor_point[i]->P()>0){
					// event if particle has zero hits, possible draw (to box edge)
					if((signed)det_hits[i].size()>det_hits_only){		
						this->draw_path_3D(i,part_vl[i]);//add either a detector hit or a box edge line to the particle histogram
					}
					//Resets and fills the particles projection histrograms which were created in memory when asigned to/drawn to pad
					for(int j=0;j<4;j++)if(projection==j||mega)part_vl[i]->Project3D(projection_names[j].c_str());					
				}
				
				if(targ_fusion&&i==0){i++;}//save on some unneeded drawing
			}
			
			//update the draws
			if(refresh_count==1){//On screen update
				
				if(display_time<0&&T>timebzero){//if hold turned on (but not first)
					tstop.Stop();
					cout << "Press ENTER to continue...";
					cin.ignore( std::numeric_limits<std::streamsize>::max(), '\n' );
				}
				T=tstop.RealTime();tstop.Continue();// Start counting display time
			}
			//(actually) update the draws
			if(mega)for(int i=0;i<4;i++){pad->cd(i+1);gPad->Modified();}
			else pad->Modified();
			pad->Update();
		}
		
		
		if(refresh_count>=refresh_rate&&refresh_count>=1){//if not enough draws just loop
			while(tstop.RealTime()-T<display_time){tstop.Continue();}//if display time too small, just wait
			
			//once lap time reached
			if(T-timebzero>run_time){//if its the end, then end
				counter=100000000;
			}else{
				for(int i=0;i<lim;i++){
					part_vl[i]->Reset();
					//Resets and fills the particles projection histrograms which were created in memory when asigned to/drawn to pad
					for(int j=0;j<4;j++)if(projection==j||mega)part_vl[i]->Project3D(projection_names[j].c_str());					
				}
				refresh_count=0;					
			}
			tstop.Continue();
		}
	}
	gPad->Update();
}}


/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// PRIVATE Members Functions  //////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////


void exp_core::reset_arrow(){
	beamarrow->Reset();
	
	double xxx=beamarrow->GetXaxis()->GetXmax();
	
	TVector3 be= TVector3(0.0,0.0,1.0);
	if(targ.target_thickness>0){
		if(targ.targ_fornmal.Angle(be)>0.001){
			be=targ.targ_fornmal;
		}
	}
	TVector3 strutA=be.Orthogonal();
	strutA.SetMag(xxx*0.05);	
	strutA.Rotate(pi/4, be); // rotation around "be"
	TVector3 strutB=strutA;
	strutB.Rotate(pi/2, be);

		
	// This draws an arrow for the beam
	for(int i=-250;i<=250;i++){
		double r=(double)i/250;
		beamarrow->Fill(0.0,r*xxx,0.0);//Y and Z are flipped for drawing
		beamarrow->Fill(strutA.X()*r,strutA.Z()*r,strutA.Y()*r);		
		beamarrow->Fill(strutB.X()*r,strutB.Z()*r,strutB.Y()*r);		
	}	
		
	
	for(int i=0;i<=500;i++){
		double r=rand.Uniform(0,1);
		double z=sqrt(r)*xxx*0.1;
		double phii=pi*rand.Uniform(-1,1);
	
		double R=z*sin(0.35);
		double x=R*cos(phii);
		double y=R*sin(phii);
		beamarrow->Fill(x,xxx-z,y);
	}
	
}


///give a vector for a detector hit or a not hit
TVector3 exp_core::path_vec_calc(int part,int det){
	TVector3 vect(0,0,0);
	TLorentzVector* labframe=lor_point[part];
	if(labframe->P()>0){
		if(det>-1&&(unsigned)det<detectors.size()){
			vect=detectors[det].hit_pos_vec(lor_point[part],offsets[part]);
		}else{
			double p=labframe->Phi(),t=labframe->Theta();
			double X=0,Y=0,Z=0;
			double Zlim=worldsize-offsets[part]->Z();
			if(t>pi*0.5)Zlim=worldsize+offsets[part]->Z();
			double Xlim=worldsize-offsets[part]->X();
			if(abs(p)>pi*0.5)Xlim=worldsize+offsets[part]->X();
			double Ylim=worldsize-offsets[part]->Y();
			if(p<0)Ylim=worldsize+offsets[part]->Y();
			
			double XY=abs(Zlim*tan(t));
			Y=XY*sin(p);
			X=XY*cos(p);
			if(abs(X)>Xlim){
				Y*=abs(Xlim)/abs(X);
				X=Xlim*X/abs(X);;
			}
			if(abs(Y)>Ylim){
				X*=abs(Ylim)/abs(Y);
				Y=Ylim*Y/abs(Y);
			}

			Z=sqrt((X*X)+(Y*Y));
			if(Z==0)Z=Zlim;
			else Z=Z/tan(t);
			vect=TVector3(X,Y,Z);
// 			vect=labframe->Vect();
// 			if(vect.Mag()>0)vect.SetMag(sqrt((X*X)+(Z*Z)+(Y*Y)));
// 			cout<<XY<<" "<<Z/vect.Z()<<" "<<Y/vect.Y()<<" "<<X/vect.X()<<endl;
		}
	}
	return vect;
}


void exp_core::draw_path_3D(int part,TH3D* hist,bool hit_only,int det){	
	
	this->max_distance_hit(part);
	TVector3 vect;
	int steps=0;
	if(stop_distance[part]>0){
		vect=lor_point[part]->Vect();
		if(vect.Mag()>0){
			vect.SetMag(stop_distance[part]);
			steps=round((stop_distance[part]/worldsize)*40.0);
		}
	}else{
		vect=this->path_vec_calc(part,det);
		steps=round((vect.Mag()/worldsize)*40.0);
	}

	steps++;
	for(int i=0;i<=steps;i++){
		if(hit_only)i=steps;
		double length = ((double)i/(double)steps);
		if(use_offsets)hist->Fill(vect.X()*length+offsets[part]->X(),vect.Z()*length+offsets[part]->Z(),vect.Y()*length+offsets[part]->Y());
		else hist->Fill(vect.X()*length,vect.Z()*length,vect.Y()*length);	
	}
}	
