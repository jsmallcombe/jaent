
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//



#include <TApplication.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TProfile2D.h>

#include <iostream>
#include <iomanip> 
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "exp_core.h"
#include "detector_class.h"
#include "auto_setup.h"
using namespace std;
int main(int argc, char *argv[]){	
// int argcb;
// char **argvb;	
TApplication *app = new TApplication("app", &argc, argv);
TH1::AddDirectory(kFALSE);//avoid name overwrites but could cause other memory histogram issues

//        h->SetDirectory(0);          for the current histogram h
	TCanvas * can_view = new TCanvas("can_view", "can_view", 1000, 1000);
	exp_core experiment(250);
	
	can_view->Divide(2,2);
	can_view->cd(1);
	
// 	experiment.set_targ(74,186);
	experiment.set_targ(W_186_straight);
	experiment.set_beam(3,7,40.0);
	experiment.set_fusion();
	experiment.set_fission();	
	experiment.set_target_interaction(2);
	mwpc_auto_setup(experiment,0,false);
	add_target_ladder(experiment,15,80,5);

	
	experiment.print_reaction();
	experiment.print_detectables();
	experiment.print_doubles();


// 	
// 	experiment.draw_target_interaction();
// 	experiment.draw_xz_labels();
	
	TH1D* AA=experiment.fission_fragment_angles(1000)->ProjectionX("AA");
	
	TH1D* XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("XX");
	experiment.set_lifetime_ns(0.00001);	
	TH1D* YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("YY");
	experiment.set_lifetime_ns(0.000005);
	TH1D* ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("ZZ");

	AA->SetLineColor(1);
	XX->SetLineColor(2);	
	YY->SetLineColor(3);
	ZZ->SetLineColor(4);
	
	XX->GetXaxis()->SetRangeUser(2.7,3.3);
	XX->SetTitle("4 Detectors Fusion");
	
	XX->DrawCopy();
	AA->DrawCopy("same");
	YY->DrawCopy("same");
	ZZ->DrawCopy("same");

	can_view->cd(2);
	
	
	experiment.set_targ(W_186_twisted);
	experiment.set_beam(3,7,40.0);
	experiment.set_fusion();
	experiment.set_fission();	
	experiment.set_target_interaction(2);
	mwpc_auto_setup(experiment,1,false);
	add_target_ladder(experiment,15,80,5);
	
	experiment.print_reaction();
	experiment.print_detectables();
	experiment.print_doubles();

	experiment.set_lifetime_ns();
	AA=experiment.fission_fragment_angles(1000)->ProjectionX("A");
	XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("X");
	experiment.set_lifetime_ns(0.00001);	
	YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("Y");
	experiment.set_lifetime_ns(0.000005);
	ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("Z");

	AA->SetLineColor(1);	
	XX->SetLineColor(2);	
	YY->SetLineColor(3);
	ZZ->SetLineColor(4);
	
	XX->GetXaxis()->SetRangeUser(2.7,3.3);
	XX->SetTitle("2 Detectors Fusion");
	
	XX->DrawCopy();
	AA->DrawCopy("same");
	YY->DrawCopy("same");
	ZZ->DrawCopy("same");

	
	
	
	experiment.set_lifetime_ns();
	
	can_view->cd(3);
	
	experiment.set_targ(W_186_straight);
	experiment.set_beam(3,7,40.0);
	experiment.set_elastic();
	experiment.set_E_star(28);
	experiment.set_uniform(0.99*pi,pi);
	experiment.set_fission();	
	experiment.set_target_interaction(2);
	mwpc_auto_setup(experiment,0,false);
	add_target_ladder(experiment,15,80,5);

	
	experiment.print_reaction();
	experiment.print_detectables();
	experiment.print_doubles();

	
	AA=experiment.fission_fragment_angles(1000)->ProjectionX("AAAA");
	
	XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("XXXX");
	experiment.set_lifetime_ns(0.0001);	
	YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("YYYY");
	experiment.set_lifetime_ns(0.001);
	ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("ZZZZ");
	AA->SetLineColor(1);
	XX->SetLineColor(2);	
	YY->SetLineColor(3);
	ZZ->SetLineColor(4);
	
	XX->GetXaxis()->SetRangeUser(2.7,3.3);
	XX->SetTitle("4 Detectors Scatter");
	
	XX->DrawCopy();
	AA->DrawCopy("same");
	YY->DrawCopy("same");
	ZZ->DrawCopy("same");

	
	
	experiment.set_lifetime_ns();	
	can_view->cd(4);
	
	experiment.set_targ(W_186_twisted);
	experiment.set_beam(3,7,40.0);
	experiment.set_elastic();
	experiment.set_E_star(28);
	experiment.set_uniform(0.99*pi,pi);
	experiment.set_fission();	
	experiment.set_target_interaction(1);
	mwpc_auto_setup(experiment,1,false);
	add_target_ladder(experiment,15,80,5);

	
	experiment.print_reaction();
	experiment.print_detectables();
	experiment.print_doubles();


	
	AA=experiment.fission_fragment_angles(1000)->ProjectionX("AAA");
	
	XX=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("XXX");
	experiment.set_lifetime_ns(0.0001);	
	YY=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("YYY");
	experiment.set_lifetime_ns(0.001);
	ZZ=experiment.fission_fragment_angles_detect(true,5000)->ProjectionX("ZZZ");
	AA->SetLineColor(1);
	XX->SetLineColor(2);	
	YY->SetLineColor(3);
	ZZ->SetLineColor(4);
	
	XX->GetXaxis()->SetRangeUser(2.7,3.3);
	XX->SetTitle("2 Detectors Scatter");
	
	XX->DrawCopy();
	AA->DrawCopy("same");
	YY->DrawCopy("same");
	ZZ->DrawCopy("same");
	
	
	
	
	
	
	
	
	
	
	
cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;	
	app->Run();
	return 0;
}	
	
	