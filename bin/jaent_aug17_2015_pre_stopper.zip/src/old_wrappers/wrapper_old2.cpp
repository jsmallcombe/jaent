
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//



#include <TApplication.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TProfile2D.h>

#include <iostream>
#include <iomanip> 
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "exp_core.h"
#include "detector_class.h"
#include "auto_setup.h"
using namespace std;
int main(int argc, char *argv[]){	
// int argcb;
// char **argvb;	
TApplication *app = new TApplication("app", &argc, argv);
TH1::AddDirectory(kFALSE);//avoid name overwrites but could cause other memory histogram issues
// TGraph::AddDirectory(kFALSE);//avoid name overwrites but could cause other memory histogram issues

//        h->SetDirectory(0);          for the current histogram h
	

	TCanvas * can_view = new TCanvas("can_view", "can_view", 800, 800);
	can_view->cd();
// 	can_view->Divide(2,1);
	exp_core experiment(50);
	experiment.set_gun(74,182,20.0);
	
	experiment.set_targ(target(74,182,10.7,-45.0,0,100000000.7,74,182));
	experiment.implant_mode=-1;
// 	experiment.set_targ("W",186);
// 	experiment.set_beam(3,6,40.0);
// 	experiment.set_elastic();
		
// 	mwpc_auto_setup(experiment,2,true,50,true);
	add_rutherford_monitor(experiment,15,15,35);/*
	add_rutherford_monitor(experiment,8,8,35);
	add_rutherford_monitor(experiment,22,22,35);*/
// 	add_rutherford_monitor(experiment,10.1,10.1,150);
	//add_rutherford_monitor(experiment,-1.51,-1.51,5);

	
// 	for(int i=0;i<15;i++)
	experiment.set_valid_part(0,true,false,true,true);/*
	experiment.set_valid_part(1,true,false,true,true);
	experiment.set_valid_part(2,false,false,true,true);*/
	experiment.setpair(0,1,true);/*
	experiment.setpair(2,0,true);*/


// 	experiment.set_E_star(0.890);
// 	experiment.set_gamma();
	experiment.set_fission();
	
	experiment.print_reaction();
	experiment.print_detectables();
	experiment.print_doubles();

	experiment.set_target_primary_offset(-30,0,-30);
//add_target_ladder(experiment,10,40,5);
	
// 	experiment.set_lifetime_ns(0.001);
	
	experiment.set_lifetime_ns(200);
	
	
	
	
// 	experiment.draw_target_interaction();
// 	experiment.set_target_interaction();
	
	
// 	can_view->Divide(2,2);
// 	can_view->cd(1);
// 	experiment.set_lifetime_ns(0.1);
// 	experiment.draw_target_interaction();
// 	can_view->cd(2);
// 	experiment.set_lifetime_ns(1);
// 	experiment.draw_target_interaction();
// 	can_view->cd(3);
// 	experiment.set_lifetime_ns(0.001);
// 	experiment.draw_target_interaction();
// 	can_view->cd(4);
// 	experiment.set_lifetime_ns(0.0001);
// 	experiment.draw_target_interaction();

	
	
// 		can_view->Divide(2,1);
// 	can_view->cd(1);
// experiment.E_PAIN[0][0]->Draw("al");
// 	can_view->cd(2);
// experiment.E_PAIN[0][1]->Draw("al");
// 	can_view->cd(3);
// experiment.E_PAIN[0][2]->Draw("al");
// 	can_view->cd(4);
// experiment.E_PAIN[0][3]->Draw("al");
// 	
	
	
	

	
	
// 	experiment.set_uniform(2.6,pi);
// 	experiment.draw_xz_labels();
	
	// 	can_view->cd(1);
	// 	experiment.draw_target_interaction();
	// 	can_view->cd(2);

// experiment.basic_det_hit_frac(10000000,0,true);
// experiment.basic_decay_check(10000000);	
	
// experiment.draw_phi(true);//best already be pointing to a pa
	experiment.draw_hits_3D(4,3,true,-1);
//void draw_hits_3D(projection,particle_hit_multiplicity,obstructions,display_time,refresh_rate,counterpart_misses,run_time)
	
	
/*	
	experiment.basic_hit_count(5000000,true);
// 	can_view->cd(1);
	
can_view->Divide(3,1);
	can_view->cd(1);
	experiment.get_det(0).energy.DrawCopy();
	can_view->cd(2);
	experiment.get_det(0).mass.DrawCopy();
	can_view->cd(3);
	experiment.get_det(0).hit_pat.DrawCopy();*/
	
	
// 	experiment.basic_hit_count(100000,true,0,2);
// 	can_view->cd(2);
// 	experiment.get_det(0).hit_pat.DrawCopy();

	
	
	
		
	
	
	
	
	
	
	
cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;	
	app->Run();
	return 0;
}	
	
	