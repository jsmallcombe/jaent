
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//



#include <TApplication.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TProfile2D.h>

#include <iostream>
#include <iomanip> 
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "exp_core.h"
#include "detector_class.h"
#include "auto_setup.h"
using namespace std;
int main(int argc, char *argv[]){	
// int argcb;
// char **argvb;	
TApplication *app = new TApplication("app", &argc, argv);
TH1::AddDirectory(kFALSE);//avoid name overwrites but could cause other memory histogram issues

//        h->SetDirectory(0);          for the current histogram h
	TCanvas * can_view = new TCanvas("can_view", "can_view", 1000, 1000);
	exp_core experiment(250);
	
// 	add_rutherford_monitor(experiment,-223.4,223.4,1.2);
	
// cout<<endl<<classical_barrier(186,74,10,5);
// cout<<endl<<classical_barrier(184,74,10,5);
// cout<<endl<<classical_barrier(182,74,10,5);
// cout<<endl<<classical_barrier(186,74,7,3);
// cout<<endl<<classical_barrier(184,74,7,3);
// cout<<endl<<classical_barrier(182,74,7,3);
// cout<<endl<<classical_barrier(186,74,6,3);
// cout<<endl<<classical_barrier(184,74,6,3);
// cout<<endl<<classical_barrier(182,74,6,3);
// 
// return 0;
// 	
cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;		
	
	
//half of four
	mwpc_auto_setup(experiment,0,false);
	experiment.set_valid_part(0,false,false,false,false);
	experiment.set_valid_part(3,false,false,false,false);
	
	experiment.set_targ(W_186_straight);
	experiment.set_beam(3,7,38);
	experiment.set_ejec(1,3);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(64);
// 	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(3,6);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(64);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(3,6);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(41.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(3,6);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(41.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(3,6);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(29);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(3,6);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(29);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(71.8);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(71.8);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(71.8);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(61.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(61.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(61.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(55.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(55.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(55.5);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(47.0);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(47.0);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(47.0);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 	
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(42.0);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_184_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(42.0);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;
// 	
// 	experiment.set_targ(W_182_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(42.0);
// 	experiment.set_fission(1,5,0.04,-1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);



// cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;			
// 
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(3,6,64);
// 	experiment.set_ejec(1,2);
//  	experiment.set_E_star(28);
// 	experiment.set_fission(0.90,5,0.04,-1);
// 	experiment.set_uniform(0,0.1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;					
// 
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(3,6,41.5);
// 	experiment.set_ejec(1,2);
//  	experiment.set_E_star(28);
// 	experiment.set_fission(0.90,5,0.04,-1);
// 	experiment.set_uniform(0,0.1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);
// 
// cout<<endl<<"///////////"<<endl;					
// 
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(3,6,29);
// 	experiment.set_ejec(1,2);
//  	experiment.set_E_star(28);
// 	experiment.set_fission(0.90,5,0.04,-1);
// 	experiment.set_uniform(0,0.1);
// 
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(5000000,false,0,0,1,1);


cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;			


	//straight pair
	mwpc_auto_setup(experiment,1,false);


cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;			

	
	experiment.set_targ(W_186_twisted);
	experiment.set_beam(3,7,50);
	experiment.set_ejec(1,3);
 	experiment.set_E_star(28);
	experiment.set_fission(0.90,5,0.04,-1);
	experiment.set_uniform(0,0.1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);

cout<<endl<<"///////////"<<endl;					

	
	experiment.set_targ(W_186_twisted);
	experiment.set_beam(3,7,40);
	experiment.set_ejec(1,3);
 	experiment.set_E_star(28);
	experiment.set_fission(0.90,5,0.04,-1);
	experiment.set_uniform(0,0.1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);

cout<<endl<<"///////////"<<endl;					

	
	experiment.set_targ(W_186_twisted);
	experiment.set_beam(3,7,34);
	experiment.set_ejec(1,3);
 	experiment.set_E_star(28);
	experiment.set_fission(0.90,5,0.04,-1);
	experiment.set_uniform(0,0.1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);

cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;
	
// 	
	experiment.set_targ(W_184_twisted);
	experiment.set_beam(3,7,50);
	experiment.set_fusion();
	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);


cout<<endl<<"///////////"<<endl;
	
// 	
	experiment.set_targ(W_182_twisted);
	experiment.set_beam(3,7,50);
	experiment.set_fusion();
	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);



cout<<endl<<"///////////"<<endl;
	
// 	
	experiment.set_targ(W_184_twisted);
	experiment.set_beam(3,7,40);
	experiment.set_fusion();
	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);


cout<<endl<<"///////////"<<endl;
	
// 	
	experiment.set_targ(W_182_twisted);
	experiment.set_beam(3,7,40);
	experiment.set_fusion();
	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);



cout<<endl<<"///////////"<<endl;
	
// 	
	experiment.set_targ(W_184_twisted);
	experiment.set_beam(3,7,34);
	experiment.set_fusion();
	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);


cout<<endl<<"///////////"<<endl;
	
// 	
	experiment.set_targ(W_182_twisted);
	experiment.set_beam(3,7,34);
	experiment.set_fusion();
	experiment.set_fission(1,5,0.04,-1);

	experiment.print_reaction();
	experiment.basic_hit_count(5000000,false,0,0,1,1);



cout<<endl<<"///////////"<<endl;
	
cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;	
	app->Run();
	return 0;
}	
	
	