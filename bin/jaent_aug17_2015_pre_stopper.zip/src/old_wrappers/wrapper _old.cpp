
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//



#include <TApplication.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TProfile2D.h>

#include <iostream>
#include <iomanip> 
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "exp_core.h"
#include "detector_class.h"
#include "auto_setup.h"
using namespace std;
int main(int argc, char *argv[]){
// int argcb;
// char **argvb;	
TApplication *app = new TApplication("app", &argc, argv);
TH1::AddDirectory(kFALSE);//avoid name overwrites but could cause other memory histogram issues
//        h->SetDirectory(0);          for the current histogram h

////////////////////////////////////////////////////////	
///show old w186 7li angular solutions with silicon
// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 1200, 800);
// 	can_view->Divide(3,1);
// 	exp_core experiment(350);
// 	
// 	experiment.set_targ("W",186);
// 	experiment.set_beam(3,7);
// 	experiment.set_ejec(1,3);
//  	experiment.set_E_star(28);
// 	experiment.set_E_beam(41.5);
// 	experiment.set_fission(0.91,5,0.04,-1);
// 	experiment.print_reaction();
// 	
//  	mwpc_auto_setup(experiment,2,false,80,true);
// 
// 	TH3D* cc=experiment.fission_fragment_transfer_angles();
// 	can_view->cd(3);
// 	cc->GetXaxis()->SetRangeUser(2,4);cc->GetZaxis()->SetRangeUser(0.785,0.96);
// 	gPad->SetGridx();gPad->SetGridy();
// 	cc->Project3D("yx")->DrawCopy("colz");
// 	cc->GetZaxis()->SetRangeUser(0,pi);
// 	can_view->cd(1);cc->Draw("colz");
// 
// 	experiment.set_fusion();
// 	experiment.set_E_beam(41.5);
// 	TH2D* bb=experiment.fission_fragment_angles_detect();
// 	can_view->cd(2);
// 	bb->GetXaxis()->SetRangeUser(2,4);
// 	gPad->SetGridx(); gPad->SetGridy();
// 	bb->Draw("colz");
// 	
// 	cc->SetShowProjection("yx colz",10);


////////////////////////////////////////////////////////	
/// //   auto_rutherford
// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 1200, 800);
// 	can_view->Divide(3,1);
// 	exp_core experiment(350);
// 	mwpc_auto_setup(experiment,4,false,80,true);
// 	
// 	experiment.set_targ("W",186);
// 	experiment.set_beam(3,7);
// 	experiment.set_elastic();
// 	experiment.set_E_beam(41.5);
// 
// // 	experiment.basic_hit_count(100000);
// // 	experiment.auto_rutherford(100000);
// // 	
// // 	cout<<endl<<endl<<experiment.set_rutherford(0.2);
// // 	experiment.basic_hit_count(10000000);
// // 	experiment.print_reaction();
// 	
// 	// Returns angle at which ruthford scattering uncleam (rad) [Inputs(A1,Z1,A2,Z2,E_cm)]
// cout<<endl<<endl<<happy_ruth_theta(7,3,186,74,20.0);


////////////////////////////////////////////////////////	
// /// Show trajectories drawing
// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 1000, 1000);
// 	can_view->cd();
// 	
// 	exp_core experiment(280);
// 	experiment.set_targ("Cm",248);
// 	experiment.set_beam("O",18);
// 	experiment.set_ejec(6,12);
//  	experiment.set_E_star(40);
// 	experiment.set_E_beam(126);
// 	experiment.set_fission(0.99,5,0.04,-1);
// 	mwpc_auto_setup(experiment,0,true,80,true);
// 	gPad->SetTheta(40);
// 	gPad->SetPhi(40);
// 		
// 	for(int i;i<4;i++){
// 		experiment.set_valid_dets(0,i);
// 		experiment.set_valid_dets(1,i);/*
// 		experiment.set_valid_dets(2,i);
// 		experiment.set_valid_dets(3,i);	*/	
// 	} 
// 
// 	gPad->SetTheta(40);
// 	gPad->SetPhi(40);
// 	experiment.draw_hits_3D(3,1,0,0,3000000,true);
// // 	//draw_hits_3D(multiplicity,refresh_rate,projection,seconds,secondstotal,obstructions,det_hits_only_bool)
/////////////////

// 	exp_core experiment(450);
// 	experiment.set_targ("Zr",90);
// 	experiment.set_beam("Zr",90);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(420);
// 	experiment.set_fission(0.65,4,0.04,115);	
// 	experiment.auto_setup(3,false,80,false);
// 	
// 	
// // TH2D* bb=experiment.fission_fragment_angles_detect();
// // can_view->cd();
// // bb->Draw("colz");
// 
// gPad->SetTheta(40);
// gPad->SetPhi(40);
// 	experiment.draw_hits_3D(2,10,0,0,3000000,true);
// 	//draw_hits_3D(multiplicity,refresh_rate,projection,seconds,secondstotal,obstructions,det_hits_only_bool)
// 	
// 	
	

////////////////////////////////////////////////////////	
///    B10 reaction + detector particle recording
// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 1200, 600);
// 	can_view->Divide(4);
// 	exp_core experiment(350);
// 	
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_beam(5,10);
// 	experiment.set_fusion();
// 	experiment.set_E_beam(71.8);
// 	experiment.set_fission(0.999,14.7,0.22,-1);
// 	experiment.print_reaction();
// 
// 	experiment.set_target_interaction(1);
// 	mwpc_auto_setup(experiment,0,false);
// // 	can_view->cd(1);
// // 	experiment.draw_xz_labels();
// 	experiment.basic_hit_count(1000000,true,2);
// // 	can_view->cd(2);
// // 	experiment.get_det(0).hit_pat.DrawCopy();
// 	can_view->cd(1);
// 	TH1D a= experiment.get_det(0).mass;
// 	TH1D b= experiment.get_det(3).mass;
// 	TH1D s= experiment.get_det(0).mass;
// 	s.Add(&b,1);
// 	s.Rebin(4);
// 	s.Draw();
// 	a.Add(&b,-1);
// 	a.Rebin(4);
// 	a.Draw("same");
// 	can_view->cd(2);
// 	a.Draw();
// 	
// 	
// 	
// 	can_view->cd(3);
// 	experiment.fission_fragment_dT(0,3)->DrawCopy();
// 	
// 	can_view->cd(4);	
// 	TH2D* bb=experiment.fission_fragment_angles_detect();
// 	bb->GetXaxis()->SetRangeUser(2,4);
// 	gPad->SetGridx(); gPad->SetGridy();
// 	bb->Draw("colz");

// can_view->Update();

// 	experiment.set_target_interaction(1);
// 	mwpc_auto_setup(experiment,0,false);//resets the detectors
// 	experiment.basic_hit_count(10000000,true,2);
// 	can_view->cd(6);
// 	experiment.get_det(0).hit_pat.DrawCopy();
// 	can_view->cd(7);
// 	a= experiment.get_det(0).mass;
// 	b= experiment.get_det(3).mass;
// 	a.Add(&b,-1);
// 	a.Rebin(2);
// 	a.Draw();
// 	can_view->cd(8);
// 	experiment.fission_fragment_dT(0,3)->DrawCopy();
// 	can_view->Update();
////////////////////////////////////////////////////////	
// ///      Thick target test
// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 800, 600);
// 	exp_core experiment(350);
// 	mwpc_auto_setup(experiment,0,false,80,true);
// 
// 	target tt= target(6,12,500000,TVector3(0.9,0.4,1));
// 	experiment.set_targ(tt);
// 
// 
// 	experiment.set_E_beam(20);//experiment.set_ejec(2,4);
// 	experiment.print_reaction();
// 	experiment.set_target_interaction(5);
// 
// 	can_view->cd();
// 	experiment.draw_exp();
// 	experiment.dist_target_hist.DrawCopy();
// 	experiment.basic_hit_count(50,true,2);
// // 	TGraph dist_target_KE_0,dist_target_beta,dist_target_P_0,dist_target_E_star,dist_target_KE_1,dist_target_P_1;

////////////////////////////////////////////////////////	
// /// testing some new functions
// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 800, 600);
// 	exp_core experiment(350);
// 	mwpc_auto_setup(experiment,0,true,80,true);
// 	experiment.print_detectables();
// 	experiment.print_reaction();
	
////////////////////////////////////////////////////////////
// 	Energy of target knocked out of target

// 	TCanvas * can_view = new TCanvas("can_view", "can_view", 1200, 800);
// 	can_view->Divide(3,2);
// 	exp_core experiment(150);
// 
// 	vector<double> x={0,10,10,-10,-10},y={-10,-10,10,10,-10};
// 	experiment.add_detector(x,y,TVector3(0.0,0.0,100),TRotation(),true,true,false);
// 	experiment.add_detector(x,y,TVector3(20,0,100),TRotation(),false,true,false);
// 	experiment.add_detector(x,y,TVector3(40,0,100),TRotation(),false,true,false);
// 	experiment.add_detector(x,y,TVector3(60,0,100),TRotation(),false,true,false);
// 
// 	experiment.set_targ(W_186_straight);
// 	experiment.set_target_interaction();
// // 	experiment.set_targ("W",186);
// 
// 	experiment.set_beam(3,6);
// 	experiment.set_elastic();	
// 	experiment.set_E_star(28);
// 	
// // 	experiment.set_fusion();
// 	experiment.set_E_beam(40);
// 	
//  	experiment.print_reaction();
// 	experiment.basic_hit_count(1000000,true,1);
// 	//experiment.draw_hits_3D(0,10,0,2,3000000,false,false);
// 	//draw_hits_3D(multiplicity,refresh_rate,projection,seconds,secondstotal,obstructions,det_hits_only_bool)
// 	
// 	can_view->cd(1);experiment.get_det(0).energy.DrawCopy();
// 	can_view->cd(2);experiment.get_det(1).energy.DrawCopy();
// 	can_view->cd(3);experiment.get_det(2).energy.DrawCopy();
// 	can_view->cd(4);experiment.get_det(3).energy.DrawCopy();
// 	can_view->cd(5);experiment.draw_exp();
// 	can_view->cd(6);experiment.draw_phi(true);
// 	can_view->Update();

	
////////////////////////////////////////////////////////////
//stopper foil experimental data
  TCanvas * can_view = new TCanvas("can_view", "can_view", 1200, 900);
	can_view->Divide(2,2);
	exp_core experiment(150);

	vector<double> x,y;
	double r=5;
	for(int i=0;i<360;i++){
	  x.push_back(r*sin((double)i*pi/180));
	  y.push_back(-r*cos((double)i*pi/180));
	}
	TRotation rot=TRotation();
	double ang=atan(32.0/80.0);
	double dist=53/sin(ang);
	rot.RotateY(-ang);
// 	experiment.add_detector(x,y,TVector3(-dist*sin(ang),0,dist*cos(ang)),rot,false,false,true);
	//experiment.add_detector(x,y,TVector3(-dist*sin(ang)-45.5*cos(ang),0,dist*cos(ang)-45.5*sin(ang)),rot,false,false,true);

// 	ang=atan(15/80.0);
// 	dist=80/cos(ang);
// 	rot=TRotation();
// 	rot.RotateY(-ang);
// 	experiment.add_detector(x,y,TVector3(-dist*sin(ang),0,dist*cos(ang)),rot,false,false,true);

	ang=atan(5/80.0);
	dist=80/cos(ang);
	rot=TRotation();
	rot.RotateY(-ang);
	experiment.add_detector(x,y,TVector3(-dist*sin(ang),0,dist*cos(ang)),rot,false,false,true);

// 	ang=atan(7/80.0);
// 	dist=80/cos(ang);
// 	rot=TRotation();
// 	rot.RotateY(-ang);
// 	experiment.add_detector(x,y,TVector3(-dist*sin(ang),0,dist*cos(ang)),rot,false,false,true);


// 	experiment.add_detector(x,y,TVector3(0.0,0.0,80),TRotation(),true,false,true);
	
// 	experiment.set_targ(target(74,186,140.0,-135.0,0,60.2,6,12));
// 	experiment.set_target_interaction(1);
	experiment.set_targ("H",2);
	experiment.set_beam(3,6);
	experiment.set_elastic();
	experiment.set_E_beam(41);
	experiment.print_reaction();
	experiment.set_ejec(1,2);
	
	
	
	
	

	experiment.set_E_beam(41);
	experiment.auto_rutherford(1000,false);	
	experiment.set_E_beam(45);
		experiment.auto_rutherford(1000,false);
	experiment.set_E_beam(65);
		experiment.auto_rutherford(1000,false);
// 	experiment.set_rutherford(0.05,0.6);
// 
//  	experiment.print_reaction();
// 	experiment.basic_hit_count(1000000,true,1);
	
	cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;

	experiment.set_uniform(0.1,1.4);
// 	experiment.set_ejec(1,2);
// 	experiment.set_E_star(28);
// 	experiment.print_reaction();
// 	experiment.basic_hit_count(10000,true,1);
	
// 	can_view->cd(1);experiment.get_det(0).energy.DrawCopy();
// // 	can_view->cd(2);experiment.get_det(1).energy.DrawCopy();
// 	can_view->cd(3);experiment.get_det(2).energy.DrawCopy();
// 	can_view->cd(4);experiment.get_det(3).energy.DrawCopy();
	can_view->cd(3);experiment.draw_exp(2);
	can_view->cd(4);experiment.draw_phi(true);
	can_view->Update();
	
	
	
// 	can_view->cd(3);
// 	TGraph xx;
// 	xx.GetXaxis()->SetTitle("CoM #Theta");
// 	for(int i=0;i<180;i++){
// 		double angle_low=(double)i*pi/720.0;
// 		double angle_high=((double)i+1)*pi/720.0;
// 		experiment.set_uniform(angle_low,angle_high);
// 		xx.SetPoint(xx.GetN(),(angle_high+angle_low)*0.5,experiment.basic_det_hit_frac(1000,0));
// 	}
// // 	xx.Draw("al");
// 	
	can_view->cd(4);
	TGraph yy;
	yy.GetXaxis()->SetTitle("CoM #Theta");
	for(int i=100;i<300;i++){
		double sigma=0.01*(double)i;
		experiment.set_zeroid(sigma);
		yy.SetPoint(yy.GetN(),sigma,experiment.basic_det_hit_frac(5000,0));
	}
	yy.Draw("al");	


experiment.set_zeroid(0.2);
	experiment.basic_hit_count(10000,true,1);
	can_view->cd(1);experiment.get_det(0).hit_pat.DrawCopy();
	experiment.add_detector(x,y,TVector3(-dist*sin(ang),0,dist*cos(ang)),rot,false,false,true);
// 	experiment.add_detector(x,y,TVector3(0.0,0.0,80),TRotation(),true,false,true);
	
experiment.set_E_beam(2060);
	experiment.set_elastic();
	
	experiment.basic_hit_count(10000,true,1);
	
	can_view->cd(2);experiment.get_det(1).hit_pat.DrawCopy();
	
	

	can_view->cd(4);
	TGraph zz;
	zz.GetXaxis()->SetTitle("CoM #Theta");
	for(int i=100;i<300;i++){
		double sigma=0.01*(double)i;
		experiment.set_zeroid(sigma);
		zz.SetPoint(zz.GetN(),sigma,experiment.basic_det_hit_frac(5000,0));
	}
	zz.Draw("same");	
		
	cout<<endl<<"/////////////////////////////////////////////////////////////////////////"<<endl;	
/////////////////////////////
	app->Run();
	return 0;
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//////


// 	exp_core experiment(350);
// 
// 	experiment.set_targ("W",186);
// 	experiment.set_beam(3,7);
// //	experiment.set_elastic();
// // 	experiment.set_fusion();
// 	experiment.set_ejec(2,4);
// 
// 	
//  	experiment.set_E_star(28);
// // 	
// // 	experiment.print_reaction();
// // 	
// // 		experiment.set_ejec(1,1);
// //  	experiment.set_E_star(28);
// // 	
// // 	experiment.print_reaction();
// // 	double get_E_beam();
// // 	double get_E_beam_min();
// 
// // 	cout<<endl<<"Previous=34 MeV";
// // 	experiment.set_E_cm_beam(ECM_low);
// // 	cout<<endl<<"Same CoM E = "<<experiment.get_E_beam()<<" MeV";
// // 	experiment.set_E_cm_beam(ECM_low+barrierB);
// // 	cout<<endl<<"Same E from barrier = "<<experiment.get_E_beam()<<" MeV";	
// // 	experiment.set_E_star(estarlow);
// // 	cout<<endl<<"Same Fusion Excitation, E beam = "<<experiment.get_E_beam()<<" MeV"<<endl;	
// 
// // 	experiment.set_E_beam(34);
// // 	double estarlow = experiment.get_reco_E_star();
// // 	experiment.print_reaction();
// // 
// 	experiment.set_E_beam(40);
// // 	double estarmed= experiment.get_reco_E_star();
// // 	//experiment.print_reaction();
// // 
// // 
// // 	experiment.set_E_beam(50);
// // 	double estarhigh = experiment.get_reco_E_star();
// // 	experiment.print_reaction();
// // 
// // 	double barrierA=experiment.get_basic_barrier_in();
// // 	
// // 	experiment.set_beam("B",10);
// // 	experiment.set_fusion();
// // 	
// // 	double barrierB=experiment.get_basic_barrier_in()-barrierA;
// // 	
// // 	cout<<endl<<"Previous=34 MeV";
// // 	experiment.set_E_cm_beam(ECM_low);
// // 	cout<<endl<<"Same CoM E = "<<experiment.get_E_beam()<<" MeV";
// // 	experiment.set_E_cm_beam(ECM_low+barrierB);
// // 	cout<<endl<<"Same E from barrier = "<<experiment.get_E_beam()<<" MeV";	
// // 	experiment.set_E_star(estarlow);
// // 	cout<<endl<<"Same Fusion Excitation, E beam = "<<experiment.get_E_beam()<<" MeV"<<endl;	
// // 
// // 	cout<<endl<<"Previous=40 MeV";	
// // 	experiment.set_E_cm_beam(ECM_med);
// // 	cout<<endl<<"Same CoM E = "<<experiment.get_E_beam()<<" MeV";
// // 	experiment.set_E_cm_beam(ECM_med+barrierB);
// // 	cout<<endl<<"Same E from barrier = "<<experiment.get_E_beam()<<" MeV";
// // 	experiment.set_E_star(estarmed);
// // 	cout<<endl<<"Same Fusion Excitation, E beam = "<<experiment.get_E_beam()<<" MeV"<<endl;
// // 
// // 	cout<<endl<<"Previous=50 MeV";	
// // 	experiment.set_E_cm_beam(ECM_high);
// // 	cout<<endl<<"Same CoM E = "<<experiment.get_E_beam()<<" MeV";
// // 	experiment.set_E_cm_beam(ECM_high+barrierB);
// // 	cout<<endl<<"Same E from barrier = "<<experiment.get_E_beam()<<" MeV";
// // 	experiment.set_E_star(estarhigh);
// // 	cout<<endl<<"Same Fusion Excitation, E beam = "<<experiment.get_E_beam()<<" MeV"<<endl;
// // 
// // 
// // 	
// // 	experiment.set_E_cm_beam(ECM_med+barrierB);
// 	experiment.set_fission(0.91,5,0.04,-1);
// // 	vector<int> validdets;
// // 	validdets.push_back(0);
// // 	validdets.push_back(1);
// // 	validdets.push_back(2);
// // 	validdets.push_back(3);	
// // 	cout<<endl<<endl<<"4 detectors fission detection rate";
// 	experiment.auto_setup(2,false,40,true);
// 	//experiment.basic_hit_count(1000000);
// // 	cout<<endl<<endl<<"2 detectors fission detection rate";
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000);
// // 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// // 	experiment.auto_setup(2,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000);
// // 	
// 	
// // 	TH2D* aa=experiment.fission_fragment_angles();
// // 	can_view->cd(1);
// // 	aa->Draw("colz");
// // 	TH2D* bb=experiment.fission_fragment_angles_detect();
// // 	can_view->cd(2);
// // 	bb->Draw("colz");
// 	
// 	TH3D* cc=experiment.fission_fragment_transfer_angles();
// 	can_view->cd(3);
// 	cc->GetXaxis()->SetRangeUser(2,4);
// 	cc->GetZaxis()->SetRangeUser(0.785,0.96);
// 	gPad->SetGridx();
//         gPad->SetGridy();
// 	cc->Project3D("yx")->DrawCopy("colz");
// 	
// 	cc->GetZaxis()->SetRangeUser(0,pi);
// 	
// 	can_view->cd(1);
// 	
// 	cc->Draw("colz");
// 
// 	experiment.set_fusion();
// 	experiment.set_E_beam(40);
// 		
// 	TH2D* bb=experiment.fission_fragment_angles_detect();
// 	can_view->cd(2);
// 	bb->GetXaxis()->SetRangeUser(2,4);
// 	gPad->SetGridx();
//         gPad->SetGridy();
// 	bb->Draw("colz");
// 
// 	
// 	cc->SetShowProjection("yx colz",10);
// 	
// // 	experiment.print_reaction();
// // 	
// // 	
// // 	experiment.set_beam(3,6);
// // 	experiment.set_fusion();
// // 	experiment.set_E_beam(41.6);
// // 	experiment.print_reaction();
// // 	experiment.set_E_beam(41.7);
// // 	experiment.print_reaction();
// // 	experiment.set_E_beam(41.8);
// // 	experiment.print_reaction();
// // 	experiment.set_E_beam(41.9);
// // 	experiment.print_reaction();
// // 	experiment.set_fusion();
// // 	experiment.set_E_beam(40.5);	
// // 	experiment.print_reaction();
// 	
// 
// 	
// // 	experiment.set_beam(3,6);
// 	
// 	
// 	
// 	
// 	
// // 	experiment.set_fission(0.91,5,0.04,true);
// 	
// // 	vector<int> validdets;
// // 	validdets.push_back(0);
// // 	validdets.push_back(1);
// // 	validdets.push_back(2);
// // 	validdets.push_back(3);	
// 
// // 	experiment.set_E_beam(35);	
// // 	
// 	
// 	
// // 	cout<<endl<<endl<<"4 detectors fission detection rate";
// // 	experiment.auto_setup(0,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors fission detection rate";
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// // 	experiment.auto_setup(2,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	
// // 	
// // 	experiment.set_E_beam(25);experiment.print_reaction();
// // 	cout<<endl<<endl<<"4 detectors fission detection rate";
// // 	experiment.auto_setup(0,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors fission detection rate";
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// // 	experiment.auto_setup(2,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);	
// // 	
// // 	
// // 	experiment.set_E_beam(17);experiment.print_reaction();
// // 	cout<<endl<<endl<<"4 detectors fission detection rate";
// // 	experiment.auto_setup(0,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors fission detection rate";
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// // 	experiment.auto_setup(2,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// 	
// // 	experiment.set_targ("W",186);
// // 	experiment.set_beam(3,6);
// // 	experiment.set_fusion();
// // 	
// // 	
// // 	experiment.set_E_beam(40);experiment.print_reaction();
// // 	cout<<endl<<endl<<"4 detectors fission detection rate";
// // 	experiment.auto_setup(0,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors fission detection rate";
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// // 	experiment.auto_setup(2,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);	
// // 	
// // 	
// // 	experiment.set_ejec(3,6);
// // 	
// // 	experiment.set_E_star(30);	
// // 	
// // 	experiment.set_E_beam(40);experiment.print_reaction();
// // 	cout<<endl<<endl<<"4 detectors fission detection rate";
// // 	experiment.auto_setup(0,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors fission detection rate";
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// // 	experiment.auto_setup(2,false,40,true);
// // 	experiment.basic_fission_hit_count(1000000,validdets);	
// 
// /*	
// 	experiment.set_E_star(30);	
// 		
// 	
// 	experiment.set_E_beam(60);experiment.print_reaction();
// 	cout<<endl<<endl<<"4 detectors fission detection rate";
// 	experiment.auto_setup(0,false,40,true);
// 	experiment.basic_fission_hit_count(1000000,validdets);
// 	cout<<endl<<endl<<"2 detectors fission detection rate";
// 	experiment.auto_setup(1,false,40,true);
// 	experiment.basic_fission_hit_count(1000000,validdets);
// 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// 	experiment.auto_setup(2,false,40,true);
// 	experiment.basic_fission_hit_count(1000000,validdets);	
// 	
// 	
// 	
// 	experiment.set_E_beam(80);experiment.print_reaction();
// 	cout<<endl<<endl<<"4 detectors fission detection rate";
// 	experiment.auto_setup(0,false,40,true);
// 	experiment.basic_fission_hit_count(1000000,validdets);
// 	cout<<endl<<endl<<"2 detectors fission detection rate";
// 	experiment.auto_setup(1,false,40,true);
// 	experiment.basic_fission_hit_count(1000000,validdets);
// 	cout<<endl<<endl<<"2 detectors off centre fission detection rate";
// 	experiment.auto_setup(2,false,40,true);
// 	experiment.basic_fission_hit_count(1000000,validdets);	
// 	*/
// 	
// // 	experiment.auto_setup(1,true,45,true);	
// // 
// // 
// // 	vector<int> validej;
// // 	validej.push_back(1);
// // 	validej.push_back(2);
// // 	vector<int> validere;
// // 	validere.push_back(13);
// // 	validere.push_back(14);	
// 	
// 	
// 	
// 
// // 	experiment.set_targ(1,3);
// // 	experiment.set_beam(2,4);
// // 	experiment.set_ejec(2,4);
// // 	experiment.set_E_star(0);
// // 	experiment.set_E_beam(40);
// // 	experiment.print_reaction();
// // 	experiment.basic_binary(1000000,validere,validej);
// 	
// // 	experiment.set_targ("W",186);
// // 	experiment.set_beam(3,6);
// // 	experiment.set_ejec(2,4);
// // 	experiment.set_E_beam(20);
// // 	experiment.set_E_star(0);	
// // 	experiment.print_reaction();
// // 	experiment.basic_binary(1000000,validere,validej);
// 
// 	
// // 
// // 	cout<<"Four det"<<endl;
// // 	experiment.set_fission();
// // 	experiment.set_fission(0.85,5,0.03);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 
// // 	cout<<"Two det"<<endl;	
// // 	experiment.auto_setup(1,false,40,true);
// // 	experiment.set_fission();
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	experiment.set_fission(0.85,5,0.03);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 
// // 	cout<<"Two off centre det"<<endl;	
// // 	experiment.set_fission();
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// // 	experiment.basic_fission_hit_count(1000000,validdets);
// 
// 
// // 	can_view->cd(1);
// // 	experiment.draw_exp();
// // 	can_view->cd(2);
// // 	experiment.draw_phi(true);
// 	
// // 	can_view->cd(1);
// // 	TH2D* ffd= experiment.fission_fragment_dist();
// // 	ffd->Draw("SURF");
// // 	can_view->cd(2);
// // 	experiment.draw_xz_labels();
// 	




	
	
	
	
	

// experiment.set_ejec(1,1);
//cout<<endl<<endl<<experiment.QVcal(6,12,8,18,2,4)<<endl;

//experiment.set_E_star(40);

// experiment.set_fission(0.85,5,0.03);

// experiment.set_E_beam(0);
// experiment.basic_fission_hit_count(1000000,validdets);


// can_view->cd(1);
// experiment.draw_boost_detectors();
// can_view->cd(2);
// experiment.draw_boost_detectors(false);

// // exp_core experiment(50);
// // experiment.auto_setup(0,true,40,true);
	
	
/*
cout<<endl<<endl<<endl;
experiment.set_E_beam(34);
experiment.print_reaction();
cout<<endl<<endl<<endl;
experiment.set_E_beam(40);
experiment.print_reaction();
cout<<endl<<endl<<endl;
experiment.set_E_beam(50);
experiment.print_reaction();

experiment.set_targ("W",186);
experiment.set_beam(1,2);
//experiment.set_ejec(0,0);
//cout<<endl<<endl<<experiment.QVcal(6,12,8,18,2,4)<<endl;

experiment.set_fusion();
cout<<endl<<endl<<endl;
experiment.print_reaction();
cout<<endl<<endl<<endl;
experiment.set_E_star(45.5);
experiment.print_reaction();
cout<<endl<<endl<<endl;
experiment.set_E_star(55.1);
experiment.print_reaction();

cout<<endl<<endl<<endl;
experiment.set_E_beam(17*2);
experiment.print_reaction();*/



// 	double a[]={0,-100};
// 	double b[]={-100,-100};
// 	double c[]={-100,100};
// 	double d[]={100,100};
// 	double e[]={100,-100};
// 	vector<double*> test;
// 	test.push_back(a);
// 	test.push_back(b);
// 	test.push_back(c);
// 	test.push_back(d);
// 	test.push_back(e);
//	experiment.add_detector(test,TVector3(0.0,0.0,50),TRotation(),true);

// 	experiment.print_doubles();
// 	experiment.auto_setup(3,true,40);
// 	experiment.print_doubles();


	//cout<<endl<<endl<<experiment.QVcal(6,12,8,180,1,2)<<endl;
	//experiment.set_boost_detectors();


// 	int readoutdetail=1;
// 	long triggerlength=200;
// 	long triggerdelay=0;
// 	int timeonoroff=0;
// 	string addresses="";
// 	string loadpath=".";
// 	string savepath=".";
// 	int readinbuffersize=1000000;
// 	vector<int> triggers;
// 	
// 	vector<string> inputs;
// 	ifstream openfile;
// 
// 	for(int i=1;i<argc;i++)inputs.push_back(argv[i]);
// 				
// 	for(int i=0;(unsigned)i<inputs.size();i++){
// 		string arg=inputs[i];
// 		stringstream strea;
// 
// 		if(arg.size()>1 && arg[0]=='-'){
// 			char bc=arg[1];
// 			arg=arg.substr(2);
// 			strea<<arg;
// 			
// 			if(bc=='r') strea>>readoutdetail;
// 			if(bc=='t') strea>>triggerlength;
// 			if(bc=='d') strea>>triggerdelay;
// 			if(bc=='T') timeonoroff=1;
// 			if(bc=='c') addresses=arg;
// 			if(bc=='l') loadpath=arg;
// 			if(bc=='s') savepath=arg;
// 			if(bc=='b') strea>>readinbuffersize;
// 			if(bc=='-'){
// 				openfile.open(arg.c_str());
// 				if(openfile.is_open()){
// 					while(openfile>>arg)inputs.push_back(arg);
// 					openfile.close();
// 				}
// 			}	
// 			if(bc=='D'){
// 				int a;
// 				TString line=arg;
// 				line.ReplaceAll(","," ");
// 				istringstream is(line.Data());
// 				while(is >> a)
// 				triggers.push_back(a);
// 			}
// 						
// 		}
// 	}
	// 	core(can_view,readoutdetail,triggerlength,triggerdelay,timeonoroff,addresses,loadpath,savepath,readinbuffersize,triggers);
// 	
// 	gSystem->ChangeDirectory(savepath.c_str());
// 	TBrowser* broone=new TBrowser();
// 	broone->Create();