
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#include "exp_core.h"

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Public Members Functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////



double exp_core::set_uniform(double thetamin,double thetamax){ //input rad,rad output in mb
	simm_dist=0;

	if(thetamin>thetamax){double xx=thetamax;thetamax=thetamin;thetamin=xx;}
	if(thetamin<0)thetamin=0;
	if(thetamax>pi)thetamax=pi;

	simm_dist_parA=cos(thetamin);
	simm_dist_parB=cos(thetamax);
	return (cos(thetamin)-cos(thetamax))/2;
}

double exp_core::set_rutherford(double thetamin,double thetamax){ //input rad,rad output in mb
	simm_dist=1;
	this->set_elastic();

	if(thetamin>thetamax){double xx=thetamax;thetamax=thetamin;thetamin=xx;}
	if(thetamin<1E-6)thetamin=1E-6;
	if(thetamax>pi)thetamax=pi;
		
	simm_dist_parA=1/pow(sin(thetamin/2),2);//thetamin
	simm_dist_parB=1/pow(sin(thetamax/2),2);//thetamax

	double cross_easy = rutherford_crosssection(beam_Z,targ_Z,KE_0_tot_CoM,thetamin,thetamax);
	
	//If thick target, cross section is an even sum (simple average) of all the partials summed,
	//Events are then of course distributed through the target weighted by the partial crosssections
	if(thick_target_calcs)if(targ.target_thickness>0){
		this->set_target_interaction(3);
		double sumpartcrosssec=0;
		for(int i=0;i<dist_target_KE_0.GetN();i++){
			double x,y;
			dist_target_KE_0.GetPoint(i,x,y);
			sumpartcrosssec+=rutherford_crosssection(beam_Z,targ_Z,y,thetamin,thetamax);
		}sumpartcrosssec/=dist_target_KE_0.GetN();
		return sumpartcrosssec;
	}
	
	return cross_easy;
}

void exp_core::set_zeroid(double sigma){
	simm_dist=2;
	simm_dist_parA=sigma;
}




void exp_core::auto_rutherford(int reps,bool obstructions){
	cout<<endl<<"Accurate up to scattering angle "<<happy_ruth_theta(beam_A,beam_Z,targ_A,targ_Z,KE_0_tot_CoM)<<" "<<flush;
	double ranges[14]={0.000001,0.00001,0.0001,0.001,0.01,0.1,0.2,0.3,0.4,0.6,1.0,1.5,2.5,pi};
	vector< double > ejectilecross;
	vector< double > recoilcross;
	for(int i=0;(unsigned)i<detectors.size();i++){
		ejectilecross.push_back(0.0); 
		recoilcross.push_back(0.0);

		this->set_valid_dets(0,i);
		this->set_valid_dets(1,i);
	}

	for(int i=1;i<14;i++){
		vector< int > ejectilecout;
		vector< int > recoilout;
		for(int j=0;(unsigned)j<detectors.size();j++){
			ejectilecout.push_back(0);
			recoilout.push_back(0);
		}
		
		double crosssecforbit=set_rutherford(ranges[i-1],ranges[i]);
// 		this->SetPrimaryDist(0,ranges[i-1],ranges[i]);
		
		for(int j=0;j<reps;j++){
			this->gen_event();
			this->det_check_hits_all(obstructions);
		
			for(int k=0;(unsigned)k<det_hits[0].size();k++){
				recoilout[det_hits[0][k]]++;
			}
		
			for(int k=0;(unsigned)k<det_hits[1].size();k++){
				ejectilecout[det_hits[1][k]]++;
			}
		}

		for(int j=0;(unsigned)j<detectors.size();j++){	
		      recoilcross[j]+=crosssecforbit*(double)recoilout[j]/(double)reps;	
			ejectilecross[j]+=crosssecforbit*(double)ejectilecout[j]/(double)reps;
		}
	}


	double pnA_mb=targ.number_density()*6.24150934E9;	
	cout<<endl<<endl<<setw(3)<<" "<<setw(14)<<"Recoil (mb)"<<setw(14)<<"Ejectile (mb)";
	if(targ.target_thickness>0)cout<<setw(16)<<"Recoil (Hz/pnA)"<<setw(18)<<"Ejectile (Hz/pnA)";
	for(int i=0;(unsigned)i<detectors.size();i++){
		cout<<endl<<setw(3)<<i<<setw(14)<<recoilcross[i]<<setw(14)<<ejectilecross[i];
		if(targ.target_thickness>0)cout<<setw(16)<<recoilcross[i]*pnA_mb<<setw(18)<<ejectilecross[i]*pnA_mb;
		
	}cout<<endl;	
}

void exp_core::auto_rutherford_OTT(int reps,bool obstructions){

	this->set_target_interaction(3);
	cout<<endl<<beam_A<<dataob.get_symb(beam_Z)<<" beam rutherford scattering on "<<targ_A<<dataob.get_symb(targ_Z)<<" target nuclei.";
	this->auto_rutherford(reps,obstructions);cout<<endl;
	
	if(targ.target_thickness>0&&targ.backing_thickness>0){
		this->set_targ(targ.inverse());
		this->set_target_interaction(3);	
		cout<<endl<<"BACKING SCATTERING";
		cout<<endl<<beam_A<<dataob.get_symb(beam_Z)<<" beam rutherford scattering on "<<targ_A<<dataob.get_symb(targ_Z)<<" backing nuclei.";
		this->auto_rutherford(reps,obstructions);cout<<endl;
		this->set_targ(targ.inverse());
	}
}

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// PRIVATE Members Functions  //////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

void exp_core::gen_uniform(){
	//Generate a random phi theta trajectory evenly distributed on a sphere
	phiM=pi*rand.Uniform(0,2);
	thetaM=acos(rand.Uniform(simm_dist_parB,simm_dist_parA));
}


void exp_core::gen_ruth(){
	//Generate a rutherford phi theta trajectory over the set range
	phiM=pi*rand.Uniform(0,2);
	double rr=rand.Uniform(simm_dist_parB,simm_dist_parA);
	thetaM=2*asin(1/sqrt(rr));
}


void exp_core::gen_zeroid(){
	//Generate a random phi theta trajectory evenly distributed on a sphere
	phiM=pi*rand.Uniform(0,2);
	thetaM=rand.Gaus(0,simm_dist_parA);
	if(thetaM>=pi||thetaM<=-pi)thetaM=pi;
}