
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#include "exp_core.h"

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Public Members Functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////


void exp_core::set_gamma(double keV){
	decay_events=true;
	decay_type=1;
	mass_decay1=targ_mass;
	mass_decay2=0.0;	
	decay_A_A=reco_A;
	decay_A_B=0;
	decay_Z_A=reco_Z;
	decay_Z_B=0;
	if(keV==0){
		P_decay_recoil_CoM=reco_E_star;
		decay_recoil_E_star=0;
	}else{
		P_decay_recoil_CoM=keV/1000;
		decay_recoil_E_star=reco_E_star-P_decay_recoil_CoM;
	}
}

void exp_core::set_b_ray(){
	decay_events=true;
	decay_type=2;
}

void exp_core::set_alpha(){
	decay_events=true;
	decay_type=3;
}



/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// PRIVATE Members Functions  //////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

// void exp_core::(){
// }
// void exp_core::gen_gamma(){
// 		P_decay_recoil_CoM=momentum_energysplit_CoM(KE_decay_tot_CoM,mass_decay1,mass_decay2);
// }