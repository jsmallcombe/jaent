
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#include "exp_core.h"


/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Public Members Functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

void exp_core::set_target_primary_offset(TVector3 offin){
	offset_primary=offin;
	if(offin.Mag()>0)use_offsets=true;
	else if(lifetime<=0) use_offsets=false;
}
void exp_core::set_target_primary_offset(double X,double Y,double Z){
	this->set_target_primary_offset(TVector3(X,Y,Z));
}

void exp_core::set_lifetime_ns(double lifetime_in,double a,double b){
	if(lifetime_in>0){
		lifetime=abs(lifetime_in);
		use_offsets=true;
		if(a>0)density_targ=a;
		if(b>0)density_back=b;
		this->print_target();
		this->make_eloss_suffering(0);
	}else{
		lifetime=0;
		if(offset_primary.Mag()<=0)use_offsets=false;
	}
}

void exp_core::set_halflife_ns(double halflife_in,double a,double b){this->set_lifetime_ns(halflife_in*log(2),a,b);};
		
/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// PRIVATE Members Functions  //////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
	
void exp_core::make_eloss_suffering_all(){
	for(int j=0;j<4;j++)this->make_eloss_suffering(j);	
}

void exp_core::make_eloss_suffering(int i){
	//reset
	for(int j=0;j<4;j++) *E_PAIN[i][j]= TGraph();
	
	double E=500.0;
	double xt=E,yt=1E10;
	double xb=E,yb=1E10;
	bool t=false,b=false;
	double R=0;
	while(E>0.050){
		if(targ.target_thickness>0){
			if(!t)R=rangen(0,*part_Z[i],*part_A[i],targ.targ_compound,targ.targ_Z,targ.targ_A,E)*1000;
			if(!(R<yt&&R>0)||t){R=E*(yt/xt);t=true;}//if stupid value produced, track linearly to zero
			E_PAIN[i][0]->SetPoint(E_PAIN[i][0]->GetN(),R,E);
			E_PAIN[i][1]->SetPoint(E_PAIN[i][1]->GetN(),E,R);
			xt=E;yt=R;
		}
		
		if(targ.backing_thickness>0){
			if(!b)R=rangen(0,*part_Z[i],*part_A[i],targ.backing_compound,targ.backing_Z,targ.backing_A,E)*1000;
			if(!(R<yb&&R>0)||b){R=E*(yb/xb);b=true;}
			E_PAIN[i][2]->SetPoint(E_PAIN[i][2]->GetN(),R,E);
			E_PAIN[i][3]->SetPoint(E_PAIN[i][3]->GetN(),E,R);
			xb=E;yb=R;
		}
		E*=0.95;
	}
	
	//add the very important zerpoint
	for(int j=0;j<4;j++)E_PAIN[i][j]->SetPoint(E_PAIN[i][j]->GetN(),0,0);
}

double exp_core::get_range(int i,bool back,double mev){
	if(mev>0){
		if(back)return E_PAIN[i][3]->Eval(mev);
		else return E_PAIN[i][1]->Eval(mev);
	}
	return 0.0;
}

double exp_core::passage(int i,bool back,double mev,double ugcm2){
	if(mev>0){
		double R=this->get_range(i,back,mev);
		if(R>ugcm2){
			if(back)return E_PAIN[i][2]->Eval(R-ugcm2);
			else return E_PAIN[i][0]->Eval(R-ugcm2);
		}
	}
	return 0.0;
}


 
double exp_core::lifetime_track(int i,double& ns,double& fraction_in){
	//calculate initial parameters
	double KE_0=get_KE(lor_point[i]);
	double beta_0=lor_point[i]->Beta();
	double mass= *part_M[i];
	TVector3 traj=lor_point[i]->Vect();

	//total target component thicknesses in um
	double eff_thick=target_effective(targ.targ_norm,traj,1.0);
	
	//some logic gate about the relative layers and trajectories
	bool beamward=false,backingward=false,b_start=false;
	if(abs(targ.targ_fornmal.Angle(traj))<pi/2)beamward=true;//going out the front
	if(targ.backing_thickness>0 && (targ.downstream_back==beamward))backingward=true;//going "towards" backing 
	if(abs(fraction_in-0.5)>0.5&&targ.backing_thickness>0)b_start=true;
	bool two_layer=false;
	if(b_start^backingward)two_layer=true;//if two layers will be traversed

	
	double frac1=fraction_in;
	double um1=giveme_um(density_targ,targ.target_thickness,false)*eff_thick;
	double um2=giveme_um(density_back,targ.backing_thickness,false)*eff_thick;		
	double thick1=targ.target_thickness*eff_thick,thick2=targ.backing_thickness*eff_thick;	
	if(b_start){
		frac1=fraction_in-1.0;//set distance from upstream
		if(fraction_in<0)frac1=fraction_in+1.0;//set distance from upstream

		swap_jd(um1,um2);
		swap_jd(thick1,thick2);
	}
	if(beamward)frac1=1-frac1;//only needed for frac1 as frac2 is always 1!
	um1*=frac1;//only needed for frac1 as frac2 is always 1!

	//////////////////////// 
	///////// start actual calculations
	////////////////////////	
	
	//calc data for complete target exit
	//calling this will sort out fraction_in if it is backing reversed

	bool stopped=false;
	double ran1=1,ran2=1,stopfrac=0,KE_exit=0,beta_exit=0;

	double KE_betw=this->passage(i,b_start,KE_0,thick1*frac1);
	ran1 = get_range(i,b_start,KE_0)/thick1;//as a fraction of the layer
	if(KE_betw>0&&two_layer){
		KE_exit=this->passage(i,!b_start,KE_betw,thick2);
		ran2 = get_range(i,!b_start,KE_betw)/thick2;//as a fraction of the layer
	}else{KE_exit=KE_betw;}
	if(KE_exit>0) beta_exit=get_beta_KE(KE_exit,mass);


	if(ran1<frac1){//no passage
		stopped=true;
		stopfrac=ran1;
		um1*=(ran1/frac1);//shrink the range down
		um2=0;
		KE_betw=0.0;
		two_layer=false;
		KE_exit=0.0;
		beta_exit=0.0;
		ran2=0.0;
	}else{ran1=frac1;}
	

	if(two_layer){
		if(ran2<1){
			stopped=true;
			stopfrac=ran2+frac1;
			um2*=ran2;
			KE_exit=0.0;
			beta_exit=0.0;
		}else{ran2=1;}
	}
	
	double x_0=um1+um2;	
	
	//////////////////////// 
	///////// start slowing stuff
	////////////////////////
	
	//Rough calc how long it takes to stop OR exit
	double rough_time_ns=(x_0/((beta_0+beta_exit)*0.5*jam_phys_speed_c_mm_ns*1000));
	rough_time_ns/=0.5*((1/sqrt(1-beta_0*beta_0))+(1/sqrt(1-beta_exit*beta_exit)));
	
	//if exit with time to spare	
	if(beta_exit>0&&!stopped){
		if(rough_time_ns*5<ns){//target interaction finished well before time out
			ns=ns-rough_time_ns;	

			if(backingward)fraction_in=-1+(3*beamward);
			else fraction_in=1.0*beamward;		

			return beta_exit;
		}
	}
	
	//if stopped with time to spare	
	if(stopped){
		if(rough_time_ns*1.5<ns){//target interaction finished well before time out
			ns=0.0;	

			if(beamward) fraction_in+=stopfrac;
			else fraction_in-=stopfrac;	

			return 0.0;
		}
	}	
	


// 	//IF we have reached this point EITHER stops shorly before decay OR decays in/near target
// 	//Do two careful loop to see if realtime expires before exit OR stop
// 	//The loops run until particle exit if it will exit OR particle stop if it will stop
// 	
	//starting conditions into loop variabls
	double KE_c=KE_0;
	double beta_c=beta_0;
	double t_t=0.0;

// 	//do 10 steps through the fraction of the first layer we must traverse
	for(int j=0;j<10;j++){
		double KE_l=this->passage(i,b_start,KE_c,thick1*0.1*ran1);
		
		//time taken to cross this section		
		double beta_l=0;
		beta_l=get_beta_KE(KE_l,mass);
		double t_l=((um1*0.1)/((beta_c+beta_l)*0.5*jam_phys_speed_c_mm_ns*1000));
		t_l/=0.5*((1/sqrt(1-beta_c*beta_c))+(1/sqrt(1-beta_l*beta_l)));	
		
		// if decayed in that 10th
		if(t_l+t_t>=ns){
			double partway=abs(ns-t_t)/t_l;
			double KEF=KE_c+((KE_c-KE_l)*partway);
			partway=0.1*((double)j+partway)*ran1;

			if(beamward) fraction_in+=partway;
			else fraction_in-=partway;

			ns=0.0;//remaining after target			
			return get_beta_KE(KEF,mass);//beta
		}			
			
		//prepare for next loop
		t_t+=t_l;
		KE_c=KE_l;
		beta_c=beta_l;
		if(KE_c==0){j=10;break;}
	}
	

	// ran2 should = 1 if particle doesnt stop
	if(two_layer){
		KE_c=KE_betw;

		//do 10 steps through the fraction of the second layer we must traverse
		for(int j=0;j<10;j++){
			double KE_l=this->passage(i,!b_start,KE_c,thick2*0.1*ran2);

			//time taken to cross this section		
			double beta_l=0;
			beta_l=get_beta_KE(KE_l,mass);
			double t_l=((um2*0.1)/((beta_c+beta_l)*0.5*jam_phys_speed_c_mm_ns*1000));
			t_l/=0.5*((1/sqrt(1-beta_c*beta_c))+(1/sqrt(1-beta_l*beta_l)));	

			//if decayed in that 10th
			if(t_l+t_t>=ns){
				double partway=abs(ns-t_t)/t_l;
				double KEF=KE_c+((KE_c-KE_l)*partway);
				partway=0.1*((double)j+partway)*ran2;

				if(beamward) fraction_in+=(partway+ran1);
				else fraction_in-=(partway+ran1);

				ns=0.0;//remaining after target			
				return get_beta_KE(KEF,mass);//beta
			}			
				
			//prepare for next loop
			t_t+=t_l;
			KE_c=KE_l;
			beta_c=beta_l;
			if(KE_c==0){j=10;break;}
		}
	}
	
	
	// IF it stops in the target and doesnt decay before this point
	if(stopped){
		ns=0.0;	

		if(beamward) fraction_in+=stopfrac;
		else fraction_in-=stopfrac;	

		return 0.0;
	}	
	
	
	//if it reached this point it has exited without decaying
	if(two_layer)frac1+=1;
	if(beamward) fraction_in+=frac1;
	else fraction_in-=frac1;
	ns-=t_t;//remaining after target			
	return beta_exit;//beta	

// 	fraction_in=2.1;
// 	return 0.0;//beta	
}
 
