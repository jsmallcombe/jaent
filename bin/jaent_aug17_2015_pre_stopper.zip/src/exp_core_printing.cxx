
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#include "exp_core.h"

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Public Members Functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

void exp_core::print_reaction(){
	if(targ.target_thickness>0&&thick_target_calcs)this->null_target_pos();
	
	if(targ_fusion){
		cout<<endl<<endl<<"  "<<this->channelnames(beam_Z,beam_A);
		cout<<" + "<<this->channelnames(targ_Z,targ_A);
		cout<<" -> "<<this->channelnames(reco_Z,reco_A);
	}else{
		cout<<endl<<endl<<"  "<<this->channelnames(targ_Z,targ_A);
		cout<<"("<<this->channelnames(beam_Z,beam_A);
		cout<<","<<this->channelnames(ejec_Z,ejec_A);
		cout<<")"<<this->channelnames(reco_Z,reco_A);		
	}
	if(reco_E_star>0)cout<<"*";
	if(decay_events){
		cout<<" -> ";
		if(ejec_A>0)cout<<this->channelnames(ejec_Z,ejec_A)<<" + ";
		cout<<this->channelnames(decay_Z_A,decay_A_A)<<" + ";
		cout<<this->channelnames(decay_Z_B,decay_A_B);
	}
	
	cout<<endl<<"Q = "<<QVal<<" MeV";
	if(!validQ)cout<<" : INVALID Q, INPUT MANUALLY."<<endl;
	if(QMan!=0.0)cout<<" : MANUAL Q.";
	
	if(reco_E_star>0)cout<<"  E* = "<< reco_E_star<<" MeV";
	
	double KEsm=QVal-reco_E_star;
	if(KEsm>0)KEsm=0;
	cout<<"  KE_CoM_min = "<<abs(KEsm)<<" MeV";
	
	cout<<"  Coul_barrier = "<<basic_barrier_in<<" MeV";

	cout<<endl<<endl<<"     E_Beam_min = "<<E_beam_min<<" MeV";
	cout<<endl<<" E_Beam_barrier = "<<E_beam_barrier<<" MeV";
	cout<<endl<<"         E_beam = "<<E_beam<<" MeV";
	cout<<"  Beta = "<<beta_CoM;	
	cout<<"  E_CoM = "<<KE_0_tot_CoM<<" MeV";	
	if(KE_0_tot_CoM+QVal-reco_E_star<0){
		cout<<endl<<"E BEAM BELOW THRESHOLD"; 
	}	
	
	
	if(decay_events){
		if(lifetime>0){
			cout<<endl<<" Lifetime = ";
			if(lifetime>=1E9)cout<<lifetime/1E9<<" s";
			if(lifetime>=1E6&&lifetime<1E9)cout<<lifetime/1E6<<" ms";
			if(lifetime>=1E3&&lifetime<1E6)cout<<lifetime/1E3<<" us";
			if(lifetime>=1&&lifetime<1E3)cout<<lifetime<<" ns";
			if(lifetime>=1E-3&&lifetime<1)cout<<lifetime*1E3<<" ps";
			if(lifetime<1E-3)cout<<lifetime*1E6<<" fs";
		}
		
		switch ( decay_type ){
			case 1:
				if(decay_recoil_E_star<0)cout<<endl<<" INVALID GAMMA ENERGY";
				cout<<endl<<" Ey = "<<P_decay_recoil_CoM*1000<<" keV. E* Final = "<<decay_recoil_E_star;
				break;
			case 2:
			//	cout<<
				break;
			case 3:
			//	cout<<
				break;
			default://fission
				cout<<endl<<" Nominal TKE : "<<TKE_fiss_zero<<" MeV";
		} 
		
	}
	
	cout<<flush;
}

void exp_core::print_detectables(){
	//0 = Recoil, 1 = Ejectile, 2 = decay_A (recoil), 3 = decay_B (eject)
	cout<<endl<<endl<<"           |";
	cout<<setw(5)<<this->channelnames(reco_Z,reco_A)<<"|";
	cout<<setw(5)<<this->channelnames(ejec_Z,ejec_A)<<"|";
	
	if(decay_events&&decay_type==0){
		cout<<"  FF | FF  |";
	}else{
		cout<<setw(5)<<this->channelnames(decay_Z_A,decay_A_A)<<"|";
		cout<<setw(5)<<this->channelnames(decay_Z_B,decay_A_B)<<"|";
	}
	cout<<endl<<"           |Recoi|Eject|Recoi|Decay|";
				
	cout<<endl;
	for(int i=0;i<this->detN();i++){
		cout<<"Detector"<<setw(3)<<i<<"|";
		for(int j=0;j<4;j++){
			if(valid_dets[j][i])cout<<"  *  |";else cout<<"     |";
		}
		cout<<endl;
	}
}


void exp_core::print_doubles()
{
	cout<<endl<<endl<<"Det";
	for(int j=0;(unsigned)j<valid_doubles.size();j++)cout<<setw(2)<<j<<" ";
	cout<<endl;
	for(int i=0;(unsigned)i<valid_doubles.size();i++){
		cout<<setw(2)<<i<<" ";
		for(int j=0;(unsigned)j<valid_doubles[i].size();j++){
			cout<<" "<<valid_doubles[i][j]<<" ";
		}
		cout<<endl;
	}
}

void exp_core::print_target(){
	
	cout<<endl<<" Target "<<this->channelnames(targ_Z,targ_A);
	if(targ.target_thickness>0){
		cout<<endl<<" Thickness "<<targ.target_thickness<<" ug/cm2. Density "<<density_targ<<" g/cm3. Thickness "<<giveme_um(density_targ,targ.target_thickness,false)<<" um"<<flush;
	}
	if(targ.backing_thickness>0){
		cout<<endl<<" Backing "<<this->channelnames(targ.backing_Z,targ.backing_A);
		cout<<endl<<" Thickness "<<targ.backing_thickness<<" ug/cm2. Density "<<density_back<<" g/cm3. Thickness "<<giveme_um(density_back,targ.backing_thickness,false)<<" um"<<flush;
	}cout<<endl;
}

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// PRIVATE Members Functions  //////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

string exp_core::channelnames(int Z,int A){
	string retstr="";
	if(A>1){
		stringstream ss;
		ss << A;
		retstr = ss.str();
	}
	if(Z==0&&A>0){retstr+="n";return retstr;}
	if(Z==A&&A>0){retstr+="p";return retstr;}
	if(Z==1&&A==2){retstr="d";return retstr;}
	if(Z==1&&A==3){retstr="t";return retstr;}
	if(Z==0&&A==0){retstr="Y";return retstr;}
	if(Z==1&&A==0){retstr="b^+";return retstr;}
	if(Z==-1&&A==0){retstr="b^-";return retstr;}
	if(Z==2&&A==2){retstr="a";return retstr;}
	retstr+=dataob.get_symb(Z);return retstr;
}