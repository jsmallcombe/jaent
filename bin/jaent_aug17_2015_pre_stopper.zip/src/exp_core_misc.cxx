
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#include "exp_core.h"

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Non-class free functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// Public Members Functions  ///////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

void exp_core::set_gun(int Z,int A,double KE){
	this->set_reaction(Z,A,Z,A,Z,A);
	this->set_E_beam(0.0);
	this->set_Q_manual(abs(KE)*2);
}


void exp_core::set_gun(int Z,int A,double KE,target T){
	this->set_beam(Z,A);
	this->set_targ(T);
	this->set_elastic();
	KE+=get_KE(get_rel_mom(abs(KE),beam_mass),targ_mass);
	this->set_E_beam(0.0);
	this->set_Q_manual(KE);
}

void exp_core::spontaniously_decay(){
	this->set_elastic();
	this->set_target_interaction_off();
	this->set_E_beam(0.0);
	this->set_Q_manual(0.0);
}

double exp_core::get_reco_E_star(){return reco_E_star;}
double exp_core::get_E_beam_min(){return E_beam_min;}
double exp_core::get_basic_barrier_in(){return basic_barrier_in;}
double exp_core::get_E_beam_barrier(){return E_beam_barrier;}
double exp_core::get_beta_CoM(){return beta_CoM;}
double exp_core::get_E_beam(){return E_beam;}
double exp_core::get_E_beam_targ(){return E_beam_targ;}
double exp_core::get_KE_0_tot_CoM(){return KE_0_tot_CoM;}
double exp_core::get_KE_1_tot_CoM(){return KE_1_tot_CoM;}

/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////// PRIVATE Members Functions  //////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
