
//jaent 1.2
//James Smallcombe 01/4/2015

//
//	exp_core class manual
//

	//
	// CONSTRUCTOR FUNCTION
	//
	// Create an "exp_core" object which will contain all the experimental data and perform calculations
	// Input world size in mm for drawring functions optional.
	exp_core(double worldsize=400);
	
/////////////////////////////////////////////////
/////////////////////////////////////////////////
///////		    SETUP 		/////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
///////////////		    PRIMARY REACTION 		/////////
	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
	
		// LEAVING DEFAULT "0.0" VALUES IN OPTIONAL PRAMETERS
		// WILL LEAVE PARAMETER UNTOUCHED NOT ZEROED
	
		// Beam, Target, Recoil and Ejectile can all be set individually or with the single functions
		void set_reaction(int beam_Z,int beam_A,int targ_Z,int targ_A,int reco_Z,int reco_A,double beam_MeV=0.0);	
		void set_reaction(string beam_Z,int beam_A,string targ_Z,int targ_A,string reco_Z,int reco_A,double beam_MeV=0.0);//use chemical symbol "Zr" etc	
		// The recoil is the target like for distributions.
		// In fusion reaction recoil is compound
		// In decay reactions the recoil decays
		
		// Using the individual functions allows for overriding the automatic mass value
		// this is NOT NEEDED to adjust Q-value or for excited recoil
		void set_beam(int/string Z,int A,double MeV=0.0,double mass=0.0);
		void set_targ(int/string Z,int A,double mass=0.0);//SEE DETAILED TARGET SECTION
		void set_reco(int/string Z,int A,double mass=0.0);
		void set_ejec(int/string Z,int A,double mass=0.0);	
		// always set beam + target first (or use gun)

		// You may set only the beam and targer and call any of the following functions
		// which will automatically set the subsequent particles
		void set_elastic();
		void set_fusion(double mass=0);
		double set_rutherford(double thetamin=0.1,double thetamax=pi);//returns mb cross section

		
		// If you are NOT interested in beam-target interaction, only in detector behaviour for example,
		// A simple particle generator can be set with
		void set_gun(int Z=6,int A=12,double KE_MeV=20.0);
		// A "recoil" and "ejectile" will both be produced. Set detector sensitivity accordingly!
		// If "medium target" interactions are required, give the target
		void set_gun(int Z,int A,double KE_MeV,target targ);
		// Cannot be used with "thick target" calculations.
		// Only the ejectile will be a "gun" particle. Set detector sensitivity accordingly!
		// In both cases distributions can be set as with normal reaction;
		// set_uniform(thetamin,thetamax) for instance if only a small area is needed.
		
		// If you are only interested in decay events
		void spontaniously_decay();
		// Cannot be used with "thick target" calculations.
		
		/////////////////////////////////////////////////
		/////////////////////////////////////////////////
		///////		Target Details		/////////
		/////////////////////////////////////////////////
		/////////////////////////////////////////////////

			// Target and interaction can be set in 3 levels of detail.
			
			// 1) For thin target experiments, just give the target nucleus
			void set_targ(int/string targ_Z,int targ_A,double targ_mass=0.0);
			// mass value (amu) is an optional override value
			// mass value will be filled automatically form stored 2012 data tables if omitted

			// 2) For medium thickness targets or targets with backings, create & pass a "target" object
			// this object is provided in the external library files.
			void set_targ(target targ,double targ_mass=0.0);
			// Reaction is assumed calulated at the centre of the target layer
			
			// Target nucleus is extracted from targ, even if target layer is a compound
			// To add reaction with backing or other compound element:
			// Repear experiment with different target and sum results 
			// For compound targ_Z targ_A can be overwritten with method 1) after setting targ
			// For backing use target targb = targ.inverse() to flip target definition
					
			// 3) For thick target (or accurate medium), AFTER setting beam and "targ" with 2) call
			void set_target_interaction(int select=0)
			// interaction point and hence energies and energy loss is randomised through the target
			// according to specific distribution "select", default uniform
			// 1 = P=E
			// 2 = P=E^2
			// 3 = P=1/E^2
			// 4 = P=E>barrier exp<barrier (beam should be set first)
			// 5 = 4.5 MeV resonance 
 			OR
			void set_target_interaction(TFormula distribution,int var=0)
			// To manually set the interaction probability function
			// Probability distribution is a TFormula given as f(x)
			// var selects x
			// 0 -> x=KE_0_tot_CoM
			// 1 -> x=P_0_CoM
			// 2 -> x=beta_CoM
			// 3 -> x=E_star (not variable in fusion reactions)
			// OR there are sim
			
			// Neither function 3) will do anything unless a "target" has been input with 2)
			
			// Calculated CoM parameters will be calculated at targ centre for 2)
			// or at dist_target_hist->Mean() for 3)
			
			// "exp_core" class gives access to public member varibales
			// The interaction probability
			TH1D dist_target_hist; 
			// And various kinematic calculations 
			TGraph dist_target_KE_0,dist_target_beta,dist_target_P_0,dist_target_E_star,dist_target_KE_1,dist_target_P_1;
			// All are given as a function of the target layer thickness 0-1
			// These are only active/functional if exp_core::set_target_interaction() has been called
			// and are overwritten every time the "PRIMARY REACTION" is adjusted.

		/////////////////////////////////////////////////
		/////////////////////////////////////////////////
		////////         Energy Settings	/////////
		/////////////////////////////////////////////////
		/////////////////////////////////////////////////
			
			// As well as being set at the same time as the reaction or beam
			// The beam energy may be set or changed at any time
			void set_E_beam(double MeV);
			// If the reaction is set to fusion, setting E_beam will change compound excitation
			// E_beam is preserved when particles/target changed
			
			// If you want to set the total CoM KE use the following to calculate and set the E_beam
			void set_E_cm_beam(double MeV);
			// This function will calculate for target energy loss if a thick target is set
			// E_cm_beam is not preserved if followed by primary reaction changes

			// set_elastic will remove any recoil excitation or Q value
			void set_elastic();
			double set_rutherford(double thetamin=0.1,double thetamax=pi);//returns mb cross section
			
			// Sets target and beam to fuse, compound nucleus (recoil) is set based on current E_beam
			void set_fusion(double mass=0.0);
		
			// To override Q value calculated from mass tables use
			void set_Q_manual(double MeV);
			// Manually set Q value will be maintained under particle change, set_Q_manual(0.0) to disable
			// For Q=0 set to very small value!
			
			// Set the excitation of the recoil (compound in the case of fusion)
			void set_E_star(double); 
			// If the reaction is set to fusion, setting will change E_beam
	

		/////////////////////////////////////////////////
		/////////////////////////////////////////////////
		////////     Reaction Distribution	/////////
		/////////////////////////////////////////////////
		/////////////////////////////////////////////////
			
			// The generated angular distribution of reaction products can be set
			// in one of several ways. This does nothing for a fusion reaction.
			// Distributions are generated in the CoM frame in terms of theta of ejectile
			double set_uniform(double thetamin=0,double thetamax=pi);//returns fraction of 4pi
			double set_rutherford(double thetamin=0.1,double thetamax=pi);//returns mb cross section
			void set_zeroid(double sigma=0.1);//gausian theta mean=0

	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
///////////////		     DECAY REACTION 		/////////
	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
				
		// No settings under decay reaction effect settings in primary reaction.
		// 
			
			currently recoil stopping in a detector before decay is not implemented so decay may be behind implant detector!
			
			
			
			
			
			
			
			
			

	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
///////////////		      DETECTORS	 		/////////
	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
//EVEN IF DECAY EVENTS RECOILS STILL TRACKED, SET THEM OFF IN ALLOWED DETECTORS IF NOT WANTED

	

	
	
	
	//
	//DETECTOR FUCTIONS
	//
	
	//Use one of the preprogrammed MWPC setups
	//Inputs:
	//1) Setup #No.
	//2) Silicon PCB in place.
	//3) Silicon distance mm.
	//4) Silicon detector elements.
	void auto_setup(int=0,bool=false,double=0,bool=false);
	
	//Describe and add one detector face
	//Inputs:
	//1) Series of [X,Y] points describing outline.
	IF DETECTOR IS FULL PHI, START AND FINISH AT X=0 Y=-ve AND GO ANTICLOCKWISE
	OTHERWISE CANNOT CROSS Y=-ve (rotate world)
	//2) World position of [0,0].
	//3) rotation out of x,y plane
	//4) Is it a full phi detector
	void add_detector(vector<double*>,TVector3,TRotation,bool=false);
	
	//set if pairs of detectors are valid mutual hits
	//print and set. NOT CURRENTLY IMPLEMENTED
	void setpair(int,int,bool=true);
	void print_doubles();

	//wipe all detector information
	void reset_detectors();
	
	//set valid detectors for the 4 particls 1)e 2)r 3)A(R,FF) 4)B(FF,a,b,y)
	void reset_valid_dets();
	void FF_set_valid_dets(int);
	//inputs [particle,detector]
	void set_valid_dets(int,int);	
	
	
	
	
	


	//Set the recoil to spontaniously decay
	//(fragment mass ratio, mass sigma (amu),TKE sigma (fraction), TKE (0=viola,<0=bent viola,>0=manual))  
	void set_fission(double=1.0,double=0.0,double=0.0,int=0);		
	void set_gamma();
	void set_b_ray();
	void set_alpha();
	void decay_off();
	
	
	
beware particles entering the back of detectors when using decays
	
	
/////////////////////////////////////////////////
/////////////////////////////////////////////////
///////	        BASIC OUTPUTS 		/////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////	

	//
	//	Drawing
	//
	//Should be pointing to a pad when these are called as they just draw
	void draw_exp();//Draw detectors 3D and arrow
	void draw_xz_labels();//Draw detectors 2D and arrow AND detector numbers
	void draw_phi(bool=false);//Draw phi and theta view (important check if using angluar or near y=-ve)
	void draw_boost_detectors(bool=true);//Draw 3D detectors as seen by recoil (if "true", else ejectile)

	void draw_hits_3D(int=1,int=1,int=0,double=0,double=120,bool=false,bool=true);
	//(multiplicity,refresh_rate,projection,seconds_perevent,total_time,obstructions,det_hits_only_bool)

	
	//Returns a TH2D of RAW fission fragment settings (mass and TKE)
	TH2D* fission_fragment_dist();
	//Returns a TH2D of DETECTED fission fragment pairs (mass and TKE)
	TH2D* fission_fragment_dist_detect(bool obstructions);
	//Returns a TH2D of RAW fission fragment pairs (dtheta dphi)
	TH2D* fission_fragment_angles();
	//Returns a TH2D of DETECTED fission fragment pairs (dtheta dphi)
	TH2D* fission_fragment_angles_detect(bool obstructions);
	//Returns a TH3D of DETECTED fission fragment pairs and transfer particle (dtheta dphi, thetatransfer)
	TH2D* fission_fragment_transfer_angles(bool obstructions);
	
	
	//text print primary reaction and beam energy calculations
	void print_reaction();
	
/////////////////////////////////////////////////
/////////////////////////////////////////////////
///////	        SIMULATIONS 		/////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

	//simulate "reps" number of events and print hits to screen (set obs if there are obstruction detectors)
	void exp_core::basic_hit_count(int reps,bool obstructions)

	void draw_hits_3D(int=4,int=1,bool=true,double=0.75,int=1,bool=true,double=120);
//void draw_hits_3D(projection,particle_hit_multiplicity,obstructions,display_time,refresh_rate,counterpart_misses,run_time)

	void draw_target_interaction();//best already be pointing to a pad

	
	void set_target_primary_offset(TVector3=(0.0,0.0,0.0));

	double set_rutherford_OTT(double=0.1,double=pi);
	double basic_det_hit_multi(int,int,bool=false);
	

	void set_lifetime_ns(double,double=0.0,double=0.0);
	void set_halflife_ns(double,double=0.0,double=0.0);	
	//currently set lifetime must be called after all reaction particles and target set