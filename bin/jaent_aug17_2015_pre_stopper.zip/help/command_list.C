
//jaent 1.2
//James Smallcombe 01/4/2015

	// constructor
	exp_core(double=400);

// Primary Reaction
	// General
	void set_reaction(int,int,int,int,int,int,double=0.0);	
	void set_reaction(string,int,string,int,string,int,double=0.0);
	void set_fusion(double=0);	
	void set_elastic();
	void set_gun(int=6,int=12,double=20.0);
	void set_gun(int,int,double,target);
	void spontaniously_decay();
	// Beam
	void set_beam(int,int,double=0.0,double=0.0);
	void set_beam(string,int,double=0.0,double=0.0);
	void set_target_interaction_off();
	void set_target_interaction(int=0);
	void set_target_interaction(TFormula,int=0);
	// Target
	void set_targ(int,int,double=0.0);
	void set_targ(target,double=0.0);
	void set_targ(string,int,double=0.0);
	// Recoil
	void set_reco(int,int,double=0.0);
	void set_reco(string,int,double=0.0);
	// Ejectile
	void set_ejec(int,int,double=0.0);
	void set_ejec(string,int,double=0.0);	
	// Energy
	void set_E_beam(double);
	void set_E_cm_beam(double);
	void set_Q_manual(double);	
	void set_E_star(double);
	double get_reco_E_star();//excitation (must be set manually if not fusion)
	double get_E_beam_min();//The minimum beam that could still give the request excitation
	double get_basic_barrier_in();//Basic barrier height
	double get_E_beam_barrier();//Beam E that matches
	double get_beta_CoM();
	double get_E_beam();
	double get_E_beam_targ();//after reaching target centre
	double get_KE_0_tot_CoM();//KE before reaction
	double get_KE_1_tot_CoM();//KE after reaction	
	//Angular Distributions
	double set_uniform(double thetamin=0,double thetamax=pi);//returns fraction of 4pi
	double set_rutherford(double thetamin=0.1,double thetamax=pi);//returns mb cross section
	void set_zeroid(double sigma=0.1);
// Decay Reaction

	void set_gamma();
	void set_b_ray();
	void set_alpha();
	void decay_off(){decay_events=false;}
	void set_fission(double=1.0,double=0.0,double=0.0,int=0);

	
///////////////////////////////////////////////
///////////   Detector management   ///////////
/////////// exp_core_detectors.cxx  ///////////
///////////////////////////////////////////////
public:
	void add_detector(vector< vector<double> >,TVector3=TVector3(0,0,1),TRotation=TRotation(),bool=false,bool=false,bool=false,bool=false,bool=false);
	void add_detector(vector<double>,vector<double>,TVector3=TVector3(0,0,1),TRotation=TRotation(),bool=false,bool=false,bool=false,bool=false,bool=false);
	void add_detector(detector,bool=false,bool=false,bool=false,bool=false);	
	
	void setpair(int,int,bool=true);
	void reset_detectors();
	void reset_valid_dets();
	
	void FF_set_valid_dets(int);
	void set_valid_dets(int,int);
	void set_valid_part(int in,bool=true,bool=true,bool=true,bool=true);

	
	void reset_doubles();	
	int detN(){return detectors.size();}
	//intentionally a copy rather than a pointer because detectors are sacred
	detector get_det(int in=0){if(in<this->detN())return detectors[in]; else return detector();}
//////////////////////////////////////////////
///////////  Miscellaneous Fn    ///////////
///////////   exp_core_misc.cxx    ///////////
//////////////////////////////////////////////
public:
	//get current physical parameters
	double get_reco_E_star();
	double get_E_beam_min();
	double get_basic_barrier_in();
	double get_E_beam_barrier();
	double get_beta_CoM();
	double get_E_beam();
	double get_E_beam_targ();
	double get_KE_0_tot_CoM();
	double get_KE_1_tot_CoM();
/////////////////////////////////////////////////
/////////// Screen Printing check setup /////////
///////////    exp_core_printing.cxx    /////////
/////////////////////////////////////////////////
public:
	void print_reaction();
	void print_detectables();
	void print_doubles();
	
//////////////////////////////////////////////////////
///////////     Main event generation      ///////////
///////////     exp_core_event_simm.cxx    ///////////
//////////////////////////////////////////////////////
public:
	void basic_hit_count(int,bool =false,int=0,int=0,int=0,int=0);
	double basic_det_hit_frac(int,int,bool=false);

//////////////////////////////////////////////////////
///////////     Primary Distributions      ///////////
///////////     Rutherford Scattering      ///////////
///////////   exp_core_distributions.cxx   ///////////
//////////////////////////////////////////////////////
public:
	// Set simm to rutherford scattering over given range
	// Returns integrated 2pi rutherford_crosssection in mb [Inputs(thetamin_cm,thetamax_cm)]
	void auto_rutherford(int=10000,bool=false);


////////////////////////////////////////////////////////////
//////////       Decay fission functions         ///////////
//////////   Parameters, event code and outputs  ///////////
//////////          exp_core_fission.cxx         ///////////
////////////////////////////////////////////////////////////
public:
	TH2D* fission_fragment_dist();
	TH2D* fission_fragment_dist_detect(bool=false);
	TH2D* fission_fragment_angles();
	TH2D* fission_fragment_angles_detect(bool=false);
	TH3D* fission_fragment_transfer_angles(bool=false);
	TH1D* fission_fragment_dT(int detA,int detB,bool=false);
	
///////////////////////////////////////////////////////
///////////     Graphical output functions  ///////////
///////////         exp_coredrawing.cxx         ///////////
///////////////////////////////////////////////////////
public:
	//drawing
	void draw_fill(int=0);//best already be pointing to a pad
	void draw_exp(int=0);//best already be pointing to a pad
	void draw_phi(bool=false);//best already be pointing to a pad
	void draw_xz_labels();//best already be pointing to a pad
	void draw_boost_detectors(bool=true);//best already be pointing to a pad
	
	void draw_hits_3D(int=4,int=1,bool=true,double=0.75,int=1,bool=true,double=120);
//void draw_hits_3D(projection,particle_hit_multiplicity,obstructions,display_time,refresh_rate,counterpart_misses,run_time)
//multiplicity only draw events with X particles hitting (0 for all events)
//refresh rate, number of traces to overlay (zero for as many as possible)
//projection 3D or 2D
//seconds minimum display time
//secondstotal run time
//obstructions standard hit modifier
//det_hits_only_bool draw counterpart miss particles to hit events


	void set_target_primary_offset(TVector3=(0.0,0.0,0.0));
	void draw_target_interaction();//best already be pointing to a pad

	void set_lifetime_ns(double,double=0.0,double=0.0);
	void set_halflife_ns(double,double=0.0,double=0.0);

	double auto_rutherford_OTT(int=10000,bool=false)
	double basic_det_hit_multi(int,int,bool=false);