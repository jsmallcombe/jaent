
//
//
// James's not Geant4 : jaent V1.3.1
// james.smallcombe@outlook.com 01/4/2015
//
//


#ifndef __DET_AUTO_H_INCLUDED__   // if x.h hasn't been included yet...
#define __DET_AUTO_H_INCLUDED__   //   #define this so the compiler knows it has been included

#include "exp_core.h"

using namespace std;


void mwpc_auto_setup(exp_core&,int=0,bool=false,double=0,bool=false);
void add_rutherford_monitor(exp_core&,double=-36,double=176.363,double=1.2);
void add_annulus(exp_core&,double=20,double=10,double=50);

void add_target_ladder(exp_core &,double=15,double=100,double=5);
void add_chamber_cylinder(exp_core &,double=300,double=100,bool=false);
void add_chamber_cubeoid(exp_core &,double=500,double=50,double=200);
	
	
	
#endif 
