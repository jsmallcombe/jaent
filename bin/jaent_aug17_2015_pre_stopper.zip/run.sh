make
./jaent_simm_one  | tee output.txt
